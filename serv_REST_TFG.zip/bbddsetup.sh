#!/bin/bash

# Establecer la contraseña de PostgreSQL
export PGPASSWORD=dit

# Función para reiniciar tablas y crear una nueva base de datos
reiniciar_y_crear_bbdds() {
    service postgresql restart
	
    local db_name1="centro_gestion"
    local db_name2="parking"

    local port=5432

    echo "Creando la Base de Datos '$db_name1' en el puerto $port."

    # Crear la base de datos centro_gestion en el puerto 5432
    PGPASSWORD=dit psql -U dit -h localhost -p "$port" -c "CREATE DATABASE $db_name1;"

    echo "Base de Datos '$db_name1' creada en el puerto $port."

    echo "Creando la Base de Datos '$db_name2' en el puerto $port."

    # Crear la base de datos parking en el puerto 5432
    PGPASSWORD=dit psql -U dit -h localhost -p "$port" -c "CREATE DATABASE $db_name2;"

    echo "Base de Datos '$db_name2' creada en el puerto $port."


    echo "Reiniciando tablas de la Base de Datos en bbdd."

    cd ./bbdd

    psql -U dit -h localhost -p "$port" -d "$db_name1" < prueba.sql

    echo "Tablas reiniciadas en bbdd."

    echo "Reiniciando tablas de la Base de Datos en bbdd_p1."

    cd ../bbdd_p1

    psql -U dit -h localhost -p "$port" -d "$db_name2" < prueba.sql

    echo "Tablas reiniciadas en bbdd_p1."
}

# Llamar a la función reiniciar_y_crear_bbdds
reiniciar_y_crear_bbdds

