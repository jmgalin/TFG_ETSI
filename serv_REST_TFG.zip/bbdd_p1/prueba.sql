\qecho -------------------
\qecho Creamos las tablas
\qecho -------------------
\i tablas.sql
\qecho -------------------
\qecho Rellenamos las tablas
\qecho -------------------
\copy ESTADO_ACTUAL from ./ficheros/estado_actual.txt
\copy INFO_PARKING from ./ficheros/info_parking.txt


