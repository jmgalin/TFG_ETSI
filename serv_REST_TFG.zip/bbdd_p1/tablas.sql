DROP TABLE IF EXISTS info_parking;
DROP TABLE IF EXISTS estado_actual;

CREATE TABLE info_parking (
  id INTEGER NOT NULL,
  type VARCHAR(255) NULL,
  name VARCHAR(255) NULL,
  category VARCHAR(255) NULL,
  chargeType VARCHAR(255) NULL,
  priceCurrency VARCHAR(255) NULL,
  priceRatePerMinute DECIMAL(5, 2) NULL,
  latitude FLOAT NULL,
  longitude FLOAT NULL,
  type_location VARCHAR(255) NULL,
  allowedVehicleType VARCHAR(255) NULL,
  address VARCHAR(255) NULL,
  city VARCHAR(255) NULL,
  country VARCHAR(255) NULL,
  postcode VARCHAR(20) NULL,
  totalSlotNumber INTEGER NULL,
  availableSlotNumber INTEGER NULL,
  occupiedSlotNumber INTEGER NULL,
  occupancy DECIMAL(5, 2) DEFAULT NULL,
  maximumAllowedHeight VARCHAR(20) NULL,
  maximumAllowedWidth VARCHAR(20) NULL,
  type_parking VARCHAR(255) NULL,
  PRIMARY KEY(id)
);


CREATE TABLE estado_actual (
  matricula VARCHAR(20) NOT NULL,
  fechayhora_entrada TIMESTAMP NULL,
  fechayhora_salida TIMESTAMP DEFAULT NULL,
  total_minutos DECIMAL(5, 2) DEFAULT NULL,
  precio_total DECIMAL(5, 2) DEFAULT NULL,
  pagada BOOL NULL,
  id_pago VARCHAR(30) NULL,
  PRIMARY KEY(matricula, fechayhora_entrada)
);


