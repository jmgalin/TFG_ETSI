\qecho -------------------
\qecho Creamos las tablas
\qecho -------------------
\i tablas.sql
\qecho -------------------
\qecho Rellenamos las tablas
\qecho -------------------
\copy USUARIOS from ./ficheros/usuarios.txt
\copy PARKING from ./ficheros/parking.txt
\copy VEHICULO from ./ficheros/vehiculos.txt



