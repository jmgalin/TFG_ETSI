DROP TABLE IF EXISTS reservas;
DROP TABLE IF EXISTS vehiculo;
DROP TABLE IF EXISTS parking;
DROP TABLE IF EXISTS usuarios;


CREATE TABLE usuarios (
  dni VARCHAR(20) NOT NULL,
  nombre VARCHAR(45) NULL,
  apellidos VARCHAR(255) NULL,
  contrasena VARCHAR(255) NULL,
  email VARCHAR(255) NULL,
  PRIMARY KEY(dni)
);

CREATE TABLE parking (
  id INTEGER NOT NULL,
  type VARCHAR(255) NULL,
  name VARCHAR(255) NULL,
  category VARCHAR(255) NULL,
  chargeType VARCHAR(255) NULL,
  priceCurrency VARCHAR(255) NULL,
  priceRatePerMinute DECIMAL(5, 2) NULL,
  latitude FLOAT NULL,
  longitude FLOAT NULL,
  type_location VARCHAR(255) NULL,
  allowedVehicleType VARCHAR(255) NULL,
  address VARCHAR(255) NULL,
  city VARCHAR(255) NULL,
  country VARCHAR(255) NULL,
  postcode VARCHAR(20) NULL,
  totalSlotNumber INTEGER NULL,
  availableSlotNumber INTEGER NULL,
  occupiedSlotNumber INTEGER NULL,
  --occupancy DECIMAL(5, 2) GENERATED ALWAYS AS (
   -- CASE 
   --   WHEN totalSlotNumber > 0 THEN occupiedSlotNumber::DECIMAL / totalSlotNumber * 100
    --  ELSE 0.00
   -- END
  --) STORED,
  occupancy DECIMAL(5, 2) DEFAULT NULL,
  maximumAllowedHeight VARCHAR(20) NULL,
  maximumAllowedWidth VARCHAR(20) NULL,
  type_parking VARCHAR(255) NULL,
  PRIMARY KEY(id)
);


CREATE TABLE vehiculo (
  matricula VARCHAR(20) NOT NULL,
  usuarios_dni VARCHAR(20) NOT NULL,
  marca VARCHAR(45) NULL,
  modelo VARCHAR(45) NULL,
  plazas INTEGER NULL,
  PRIMARY KEY(matricula),
  FOREIGN KEY(usuarios_dni)
    REFERENCES usuarios(dni)
      ON DELETE CASCADE
      ON UPDATE CASCADE
);

CREATE TABLE reservas (
	reserva_id SERIAL,
    vehiculo_matricula VARCHAR(20) NOT NULL,
    parking_id INTEGER NOT NULL,
    fecha_inicio TIMESTAMP NULL,
    fecha_fin TIMESTAMP NULL,
    confirmada BOOL NULL,
    precio_reserva DECIMAL(5, 2) NULL,
	PRIMARY KEY(reserva_id, vehiculo_matricula, fecha_inicio),
    FOREIGN KEY (vehiculo_matricula)
        REFERENCES vehiculo(matricula)
            ON DELETE CASCADE
            ON UPDATE CASCADE,
    FOREIGN KEY (parking_id)
        REFERENCES parking(id)
            ON DELETE CASCADE
            ON UPDATE CASCADE
);


