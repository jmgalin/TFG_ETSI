package parking1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import parking1.entity.EstadoActual;
import parking1.entity.Parking;
import parking1.repository.EstadoActualRepository;
import parking1.repository.ParkingRepository;
import java.time.LocalDateTime;


@Service
public class EstadoActualService {

	private static final Long ID_PARKING = 1L;

    private final EstadoActualRepository estadoActualRepository;
    private final ParkingRepository parkingRepository;

    @Autowired
    public EstadoActualService(EstadoActualRepository estadoActualRepository, ParkingRepository parkingRepository) {
        this.estadoActualRepository = estadoActualRepository;
        this.parkingRepository = parkingRepository;
    }

    public EstadoActual getEstadoActualByMatricula(String matricula) {
        return estadoActualRepository.findByMatricula(matricula);
    }

    public void registrarEstadoActual(EstadoActual estadoActual) {
        // Obtener el estacionamiento por su ID
        Parking parking = parkingRepository.findById(ID_PARKING).orElse(null);

        if (parking != null) {
            // Incrementar occupiedSlotNumber y decrementar availableSlotNumber
            int occupiedSlots = parking.getOccupiedSlotNumber() + 1;
            int availableSlots = parking.getAvailableSlotNumber() - 1;
			int totalSlots = parking.getTotalSlotNumber();
            parking.setOccupiedSlotNumber(occupiedSlots);
            parking.setAvailableSlotNumber(availableSlots);

			float occupancy;
            if (totalSlots > 0) {
				occupancy = ((float) occupiedSlots / totalSlots);
            } else {
                occupancy = 0.0f;
            }
			parking.setOccupancy(occupancy);
            // Guardar los cambios en el estacionamiento
            parkingRepository.save(parking);

            // Guardar el estado actual en la tabla estado_actual
            estadoActualRepository.save(estadoActual);
        }
    }

	public void actualizarEstadoActual(EstadoActual estadoActual) {
        // Obtener el estacionamiento por su ID
        Parking parking = parkingRepository.findById(ID_PARKING).orElse(null);

        if (parking != null) {
            // Guardar el estado actual en la tabla estado_actual
            estadoActualRepository.save(estadoActual);
        }
    }

	public void actualizarPago(EstadoActual estadoActual) {
        // Obtener el estacionamiento por su ID
        Parking parking = parkingRepository.findById(ID_PARKING).orElse(null);

        if (parking != null) {

			// Incrementar occupiedSlotNumber y decrementar availableSlotNumber
            int occupiedSlots = parking.getOccupiedSlotNumber() - 1;
            int availableSlots = parking.getAvailableSlotNumber() + 1;
			int totalSlots = parking.getTotalSlotNumber();
            parking.setOccupiedSlotNumber(occupiedSlots);
            parking.setAvailableSlotNumber(availableSlots);

			float occupancy;
            if (totalSlots > 0) {
                //occupancy = ((float) occupiedSlots / totalSlots) * 100;
				occupancy = ((float) occupiedSlots / totalSlots);
            } else {
                occupancy = 0.0f;
            }
			parking.setOccupancy(occupancy);
            // Guardar los cambios en el estacionamiento
            parkingRepository.save(parking);

            // Guardar el pago
            estadoActualRepository.save(estadoActual);
        }
    }

	public float calcularPrecio(float minutosEstacionado) {
        // Obtener el precio del parking
		Parking parking = parkingRepository.findById(ID_PARKING).orElse(null);
        Float precioParking = parking.getPriceRatePerMinute();
		
		Float total = minutosEstacionado * precioParking;
        // Calcular el precio total en base a los minutos estacionados y el precio del parking
        return total;
    }


    // Otros métodos de servicio según sea necesario
}


