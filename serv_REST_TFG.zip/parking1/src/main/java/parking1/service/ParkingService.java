package parking1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import parking1.entity.Parking;
import parking1.repository.ParkingRepository;

import java.util.List;

@Service
public class ParkingService {

    private final ParkingRepository parkingRepository;

    @Autowired
    public ParkingService(ParkingRepository parkingRepository) {
        this.parkingRepository = parkingRepository;
    }

    public List<Parking> getAllParking() {
        return parkingRepository.findAll();
    }

    public Parking getParkingById(Long id) {
        return parkingRepository.findById(id).orElse(null);
    }

	public void updateParking(Parking parking, int totalSlotNumber, int occupiedSlotNumber, float priceRatePerMinute, String chargeType) {
		// Actualizar los campos del parking
		parking.setTotalSlotNumber(totalSlotNumber);
		parking.setOccupiedSlotNumber(occupiedSlotNumber);
		parking.setPriceRatePerMinute(priceRatePerMinute);
		parking.setChargeType(chargeType);

		// Calcular el valor de ocupación
		//float occupancy = (float) occupiedSlotNumber / totalSlotNumber * 100;
		float occupancy = ((float) occupiedSlotNumber / totalSlotNumber);
		parking.setOccupancy(occupancy);
		
		// Calcular el número de espacios disponibles
		int availableSlotNumber = totalSlotNumber - occupiedSlotNumber;
		parking.setAvailableSlotNumber(availableSlotNumber);

		// Guardar los cambios en la base de datos
		parkingRepository.save(parking);
	}
}

