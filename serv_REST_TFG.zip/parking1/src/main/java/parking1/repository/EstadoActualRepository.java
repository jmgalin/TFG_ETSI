package parking1.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import parking1.entity.EstadoActual;

public interface EstadoActualRepository extends JpaRepository<EstadoActual, String> {
	EstadoActual findByMatricula(String matricula);

}
