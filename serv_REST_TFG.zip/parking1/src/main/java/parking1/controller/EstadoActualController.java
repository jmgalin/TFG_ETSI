package parking1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import parking1.entity.EstadoActual;
import parking1.service.EstadoActualService;
import parking1.service.ParkingService;
import parking1.entity.Parking;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

@RestController
@RequestMapping("/api/parking")
public class EstadoActualController {

	private static final Long ID_PARKING = 1L;

    private final EstadoActualService estadoActualService;
    private final ParkingService parkingService; // Inyectar el servicio InfoParkingService

    @Autowired
    public EstadoActualController(EstadoActualService estadoActualService, ParkingService parkingService) {
        this.estadoActualService = estadoActualService;
        this.parkingService = parkingService; // Inicializar el servicio InfoParkingService
    }

    @PostMapping("/entrada")
    public ResponseEntity<String> registrarEstadoActual(@RequestParam String matricula) {
        // Verificar si ya existe un estado actual para la matrícula
        EstadoActual estadoActualExistente = estadoActualService.getEstadoActualByMatricula(matricula);

        if (estadoActualExistente != null && estadoActualExistente.getFechaHoraSalida() == null && estadoActualExistente.getPagada() != true) {
            System.out.println("El vehículo con matrícula " + matricula + " ya está en el parking.");
            return ResponseEntity.badRequest().body("El vehículo con matrícula " + matricula + " ya está en el parking.");
        }

		// Verificar si hay espacios disponibles en el parking
		Parking parking = parkingService.getParkingById(ID_PARKING);
		if (parking.getAvailableSlotNumber() <= 0) {
		    // No hay espacios disponibles en el parking
		    System.out.println("El parking está lleno. No se puede permitir la entrada del vehículo con matrícula " + matricula);
		    return ResponseEntity.badRequest().body("El parking está lleno. No se puede permitir la entrada del vehículo con matrícula " + matricula);
		}

        // Obtener la fecha y hora actual
        LocalDateTime fechaHoraEntrada = LocalDateTime.now();

        // Crear un nuevo estado actual
        EstadoActual nuevoEstadoActual = new EstadoActual();
        nuevoEstadoActual.setMatricula(matricula);
        nuevoEstadoActual.setFechaHoraEntrada(fechaHoraEntrada);
		nuevoEstadoActual.setPagada(false);

        // Insertar el estado actual en la base de datos
        estadoActualService.registrarEstadoActual(nuevoEstadoActual);

        System.out.println("Ha entrado un vehículo con matrícula: " + matricula);
        return ResponseEntity.ok("Se ha registrado correctamente la entrada con matricula " + matricula);
    }

	@PostMapping("/salida")
	public ResponseEntity<String> registrarSalida(@RequestParam String matricula) {
		// Verificar si el vehículo está registrado en el estado actual
		EstadoActual estadoActual = estadoActualService.getEstadoActualByMatricula(matricula);

		if (estadoActual == null) {
		    System.out.println("El vehículo con matrícula " + matricula + " no está en el parking.");
		    return ResponseEntity.badRequest().body("El vehículo con matrícula " + matricula + " no está en el parking.");
		}

		// Verificar si ya se ha registrado una salida para este vehículo y el pago es true
		if (estadoActual.getFechaHoraSalida() != null && estadoActual.getPagada() == true) {
		    System.out.println("La salida del vehículo con matrícula " + matricula + " ya ha sido registrada.");
		    return ResponseEntity.badRequest().body("La salida del vehículo con matrícula " + matricula + " ya ha sido registrada.");
		}

		// Obtener la fecha y hora actual
		LocalDateTime fechaHoraSalida = LocalDateTime.now();

		// Calcular los minutos totales
		float minutosDiferencia = ChronoUnit.MINUTES.between(estadoActual.getFechaHoraEntrada(), fechaHoraSalida);

		// Calcular el precio total
		float precioTotal = estadoActualService.calcularPrecio(minutosDiferencia);

		// Actualizar el estado actual con la fecha y hora de salida, minutos totales y precio
		estadoActual.setFechaHoraSalida(fechaHoraSalida);
		estadoActual.setTotalMinutos(minutosDiferencia);
		estadoActual.setPrecio_total(precioTotal);
		estadoActual.setPagada(false);

		// Actualizar el estado actual en la base de datos
		estadoActualService.actualizarEstadoActual(estadoActual);

		System.out.println("Ha salido un vehículo con matrícula: " + matricula);
		return ResponseEntity.ok("Salida registrada correctamente con matrícula: " + matricula + " y precio: " + precioTotal);
	}
	
	@PostMapping("/pago")
    public ResponseEntity<String> registrarPago(@RequestParam String matricula, @RequestParam String id_pago) {
        // Verificar si ya existe un estado actual para la matrícula
        EstadoActual estadoActual = estadoActualService.getEstadoActualByMatricula(matricula);

		// Verificar si el estado actual es nulo, lo que significa que la matrícula no está registrada en el parking
		if (estadoActual == null) {
		    System.out.println("No se encontró ningún vehículo con la matrícula " + matricula + " en el parking.");
		    return ResponseEntity.badRequest().body("No se encontró ningún vehículo con la matrícula " + matricula + " en el parking.");
		}

		// Verificar si ya se ha realizado el pago
		if (estadoActual.getPagada() == true && estadoActual.getId_pago() != null) {
		    System.out.println("El pago del vehículo con matrícula " + matricula + " ya ha sido realizado.");
		    return ResponseEntity.badRequest().body("El pago del vehículo con matrícula " + matricula + " ya ha sido realizado.");
		}
			
        // Actualizar datos de pagado e id del pago
        estadoActual.setPagada(true);
		estadoActual.setId_pago(id_pago);

        // Insertar el estado actual en la base de datos
        estadoActualService.actualizarPago(estadoActual);


        System.out.println("Pago registrado correctamente de matrícula: " + matricula);
        return ResponseEntity.ok("Pago registrado correctamente de matricula: " + matricula);
    }
}

