package parking1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;
import parking1.entity.Parking;
import parking1.service.ParkingService;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Arrays;
import java.util.stream.Collectors;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/parking")
public class ParkingController {

    private final ParkingService parkingService;

    @Autowired
    public ParkingController(ParkingService parkingService) {
        this.parkingService = parkingService;
    }

    @GetMapping()
    public ResponseEntity<List<Object>> getInfoParking() {
        List<Parking> availableParking = parkingService.getAllParking();

        List<Object> formattedResponse = availableParking.stream()
                .map(parking -> formatParkingInfo(parking))
                .collect(Collectors.toList());

        return ResponseEntity.ok(formattedResponse);
    }

    private Object formatParkingInfo(Parking parking) {
        Map<String, Object> parkingInfo = new HashMap<>();

        parkingInfo.put("id", parking.getId());
        parkingInfo.put("name", parking.getName());
        parkingInfo.put("chargeType", parking.getChargeType());
        parkingInfo.put("priceCurrency", parking.getPricecurrency());
        parkingInfo.put("priceRatePerMinute", parking.getPriceRatePerMinute());
        parkingInfo.put("totalSlotNumber", parking.getTotalSlotNumber());
        parkingInfo.put("availableSlotNumber", parking.getAvailableSlotNumber());
		parkingInfo.put("occupiedSlotNumber", parking.getOccupiedSlotNumber());
        parkingInfo.put("occupancy", (parking.getOccupancy()));

        return parkingInfo;
    }

	@PostMapping()
	public ResponseEntity<String> updateParking(
		@RequestParam int totalSlotNumber,
		@RequestParam int occupiedSlotNumber,
		@RequestParam float priceRatePerMinute,
		@RequestParam String chargeType) {

		Parking parking = parkingService.getParkingById(1L); // El id para este parking es el 1

		if (parking == null) {
		    return ResponseEntity.badRequest().body("El parking no se encontró en la base de datos.");
		}

		// Llamar al método del servicio para actualizar el parking
		parkingService.updateParking(parking, totalSlotNumber, occupiedSlotNumber, priceRatePerMinute, chargeType);
		System.out.println("Se han actualizado correctamente los datos del parking");
		return ResponseEntity.ok("El parking ha sido actualizado correctamente.");
	}

}

