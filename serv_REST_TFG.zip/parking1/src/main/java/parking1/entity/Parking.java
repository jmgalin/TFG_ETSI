package parking1.entity;

import javax.persistence.*;

@Entity
@Table(name = "info_parking")
public class Parking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String type;
    private String name;
    private String category;
    private String chargetype;
	private String pricecurrency;
    private Float pricerateperminute;
    private Float latitude;
	private Float longitude;
    private String type_location;
    private String allowedvehicletype;
    private String address;
    private String city;
    private String country;
    private String postcode;
    private Integer totalslotnumber;
    private Integer availableslotnumber;
    private Integer occupiedslotnumber;
	private Float occupancy;
    private String maximumallowedheight;
    private String maximumallowedwidth;
	private String type_parking;

    // Constructores, getters y setters

    // Constructor por defecto requerido por JPA
    public Parking() {
    }

    // Constructor con parámetros
    public Parking(String type, String name, String category, String chargetype, String pricecurrency, 
				   Float pricerateperminute, Float latitude, Float longitude,
				   String type_location, String allowedvehicletype, String address, String city, 
				   String country, String postcode, Integer totalslotnumber, Integer availableslotnumber,
                   Integer occupiedslotnumber, Float occupancy, String maximumallowedheight, 
				   String maximumallowedwidth, String type_parking) {
        this.type = type;
        this.name = name;
        this.category = category;
        this.chargetype = chargetype;
		this.pricecurrency = pricecurrency;
		this.pricerateperminute = pricerateperminute;
        this.latitude = latitude;
		this.longitude = longitude;
		this.type_location = type_location;
        this.allowedvehicletype = allowedvehicletype;
        this.address = address;
        this.city = city;
        this.country = country;
        this.postcode = postcode;
        this.totalslotnumber = totalslotnumber;
        this.availableslotnumber = availableslotnumber;
        this.occupiedslotnumber = occupiedslotnumber;
		this.occupancy = occupancy;
        this.maximumallowedheight = maximumallowedheight;
        this.maximumallowedwidth = maximumallowedwidth;
		this.type_parking = type_parking;
    }

    // Getters y setters

    public Long getId() {
        return id;
    }

	public void setId(Long id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public String getName() {
        return name;
    }

    public String getCategory() {
        return category;
    }

    public String getChargeType() {
        return chargetype;
    }

	public void setChargeType(String chargetype) {
        this.chargetype = chargetype;
    }
	
	public String getPricecurrency() {
        return pricecurrency;
    }

    public Float getPriceRatePerMinute() {
        return pricerateperminute;
    }

	public void setPriceRatePerMinute(Float pricerateperminute) {
        this.pricerateperminute = pricerateperminute;
    }

    public Float getLatitude() {
        return latitude;
    }

	public Float getLongitude() {
        return longitude;
    }

	public String getType_Location() {
        return type_location;
    }

    public String getAllowedVehicleType() {
        return allowedvehicletype;
    }

    public String getAddress() {
        return address;
    }

    public String getCity() {
        return city;
    }

    public String getCountry() {
        return country;
    }

    public String getPostcode() {
        return postcode;
    }

    public Integer getTotalSlotNumber() {
        return totalslotnumber;
    }

	public void setTotalSlotNumber(Integer totalslotnumber) {
        this.totalslotnumber = totalslotnumber;
    }

    public Integer getAvailableSlotNumber() {
        return availableslotnumber;
    }

	public void setAvailableSlotNumber(Integer availableslotnumber) {
        this.availableslotnumber = availableslotnumber;
    }

    public Integer getOccupiedSlotNumber() {
        return occupiedslotnumber;
    }

	public void setOccupiedSlotNumber(Integer occupiedslotnumber) {
        this.occupiedslotnumber = occupiedslotnumber;
    }

	public Float getOccupancy() {
        return occupancy;
    }

	public void setOccupancy(Float occupancy) {
        this.occupancy = occupancy;
    }


    public String getMaximumAllowedHeight() {
        return maximumallowedheight;
    }

    public String getMaximumAllowedWidth() {
        return maximumallowedwidth;
    }

	public String getType_Parking() {
        return type_parking;
    }

    // Otros métodos si es necesario
}

