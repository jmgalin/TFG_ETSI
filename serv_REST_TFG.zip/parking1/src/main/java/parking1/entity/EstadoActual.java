package parking1.entity;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "estado_actual")
public class EstadoActual {

    @Id
    private String matricula;

    @Column(name = "fechayhora_entrada")
    private LocalDateTime fechaHoraEntrada;

    @Column(name = "fechayhora_salida")
    private LocalDateTime fechaHoraSalida;

    @Column(name = "total_minutos")
    private double totalMinutos;

	private Float precio_total;

	private Boolean pagada;

	private String id_pago;

    // Constructores

    public EstadoActual() {
    }

    public EstadoActual(String matricula, LocalDateTime fechaHoraEntrada, LocalDateTime fechaHoraSalida, double totalMinutos, Float precio_total, Boolean pagada, String id_pago) {
        this.matricula = matricula;
        this.fechaHoraEntrada = fechaHoraEntrada;
        this.fechaHoraSalida = fechaHoraSalida;
        this.totalMinutos = totalMinutos;
		this.precio_total = precio_total;
		this.pagada = pagada;
		this.id_pago = id_pago;
    }

    // Getters y Setters

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public LocalDateTime getFechaHoraEntrada() {
        return fechaHoraEntrada;
    }

    public void setFechaHoraEntrada(LocalDateTime fechaHoraEntrada) {
        this.fechaHoraEntrada = fechaHoraEntrada;
    }

    public LocalDateTime getFechaHoraSalida() {
        return fechaHoraSalida;
    }

    public void setFechaHoraSalida(LocalDateTime fechaHoraSalida) {
        this.fechaHoraSalida = fechaHoraSalida;
    }

    public double getTotalMinutos() {
        return totalMinutos;
    }

    public void setTotalMinutos(double totalMinutos) {
        this.totalMinutos = totalMinutos;
    }

	public void setPrecio_total(Float precio_total) {
        this.precio_total = precio_total;
    }


	public boolean getPagada() {
        return pagada;
    }

    public void setPagada(boolean pagada) {
        this.pagada = pagada;
    }

	public String getId_pago() {
        return id_pago;
    }

    public void setId_pago(String id_pago) {
        this.id_pago = id_pago;
    }

}
