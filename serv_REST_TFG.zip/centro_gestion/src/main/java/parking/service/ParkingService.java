package parking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import parking.entity.Parking;
import parking.repository.ParkingRepository;

import java.util.List;
import java.util.Optional;


@Service
public class ParkingService {

    private final ParkingRepository parkingRepository;

    @Autowired
    public ParkingService(ParkingRepository parkingRepository) {
        this.parkingRepository = parkingRepository;
    }

	public boolean existeParkingConLatitudYLongitud(Float latitude, Float longitude) {
        return parkingRepository.findByLatitudeAndLongitude(latitude, longitude) != null;
    }

    public List<Parking> getAllParking() {
        return parkingRepository.findAll();
    }

    public Parking getParkingById(Long id) {
        return parkingRepository.findById(id).orElse(null);
    }


    /*public void saveAll(List<Parking> parkingList) {
        parkingRepository.saveAll(parkingList);
    }*/

	public void registrarParking(Parking parking) {

		// Guardar el nuevo parking en la base de datos
		parkingRepository.save(parking);
	}
	
	// Obtener el máximo id actual
	public Long getMaxId() {
        // Obtener todos los parkings de la base de datos
        List<Parking> allParkings = parkingRepository.findAll();

        // Encontrar el máximo id entre todos los parkings
        Long maxId = 0L;
        for (Parking parking : allParkings) {
            if (parking.getId() > maxId) {
                maxId = parking.getId();
            }
        }

        return maxId;
    }


	public void saveAll(List<Parking> newParkingList) {
    // Obtener la lista de parkings existentes
    List<Parking> existingParkingList = parkingRepository.findAll();

    for (Parking newParking : newParkingList) {
        // Buscar el parking correspondiente en la lista existente
        Optional<Parking> existingParkingOptional = existingParkingList.stream()
                .filter(p -> p.getId() == newParking.getId())
                .findFirst();

        existingParkingOptional.ifPresent(existingParking -> {
            // Actualizar los parámetros deseados
            existingParking.setName(newParking.getName());
            existingParking.setChargeType(newParking.getChargeType());
			//Tiene que ser todo minuscula, cambiar al formato estandar en parking controller de parking 1
			existingParking.setPriceRatePerMinute(newParking.getPriceRatePerMinute());
            existingParking.setTotalSlotNumber(newParking.getTotalSlotNumber());
            existingParking.setAvailableSlotNumber(newParking.getAvailableSlotNumber());
            existingParking.setOccupiedSlotNumber(newParking.getOccupiedSlotNumber());
            existingParking.setOccupancy(newParking.getOccupancy());

            // Guardar el parking actualizado en la base de datos
            parkingRepository.save(existingParking);
        });
    }
}


    // Otros métodos si es necesario
}

