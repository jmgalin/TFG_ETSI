package parking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.*;
import java.time.LocalDateTime;
import parking.entity.Parking;
import parking.entity.Reserva;
import parking.entity.Vehiculo;
import parking.repository.ReservaRepository;

@Service
public class ReservaService {

    private final ReservaRepository reservaRepository;

    @Autowired
    public ReservaService(ReservaRepository reservaRepository) {
        this.reservaRepository = reservaRepository;
    }

    @Transactional
    public void registrarReserva(Reserva reserva) {
        reservaRepository.save(reserva);
    }

	public List<Reserva> obtenerReservaPorMatricula(String matricula) {
        return reservaRepository.findByVehiculo_Matricula(matricula);
    }

	public List<Reserva> obtenerReservaPorParkingId(Long parkingId) {
        return reservaRepository.findByParking_Id(parkingId);
    }

	public Reserva obtenerReservaPorId(Long id) {
        return reservaRepository.findById(id).orElse(null);
    }

	public boolean existeReserva(Vehiculo vehiculo, Parking parking, LocalDateTime fecha_inicio) {
        // Buscar reservas para el vehículo, en el mismo parking y con la misma fecha de inicio
        List<Reserva> reservas = reservaRepository.findByVehiculoAndParkingAndFechaInicio(vehiculo, parking, fecha_inicio);
        return !reservas.isEmpty();
    }

	@Transactional
    public void eliminarReserva(Reserva reserva) {
        reservaRepository.delete(reserva);
    }


    // Otros métodos si es necesario
}


