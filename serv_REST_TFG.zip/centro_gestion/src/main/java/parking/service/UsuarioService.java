package parking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import parking.entity.Usuario;
import parking.repository.UsuarioRepository;

import java.util.Optional;

@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

    @Autowired
    public UsuarioService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    public Usuario getUsuarioByDni(String dni) {
        Optional<Usuario> optionalUsuario = usuarioRepository.findById(dni);
        return optionalUsuario.orElse(null);
    }

    public boolean existeUsuario(String dni) {
        return usuarioRepository.existsById(dni);
    }


	public Usuario getLoginByDni(String dni) {
        return usuarioRepository.findById(dni).orElse(null);
    }

    public void saveLogin(Usuario usuario) {
        usuarioRepository.save(usuario);
    }

    // Otros métodos de servicio según sea necesario

}

