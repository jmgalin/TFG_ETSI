package parking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import parking.entity.Vehiculo;
import parking.entity.Usuario;
import parking.repository.VehiculoRepository;

import java.util.List;
import java.util.*;


@Service
public class VehiculoService {

    private final VehiculoRepository vehiculoRepository;

    @Autowired
    public VehiculoService(VehiculoRepository vehiculoRepository) {
        this.vehiculoRepository = vehiculoRepository;
    }

    public List<Vehiculo> getVehiculosByUsuarioDni(String dni) {
        return vehiculoRepository.findByUsuarioDni(dni);
    }

	/*public boolean existeVehiculo(String matricula) {
        return vehiculoRepository.existsById(matricula);
    }*/
	public boolean existeVehiculo(String matricula, String dni) {
		Vehiculo vehiculo = vehiculoRepository.findById(matricula).orElse(null);
		return vehiculo != null && vehiculo.getUsuario().getDni().equals(dni);
	}	

    public void registrarVehiculo(Vehiculo vehiculo) {
        vehiculoRepository.save(vehiculo);
    }

	public Vehiculo getByMatricula(String matricula) {
        return vehiculoRepository.findById(matricula).orElse(null);
    }


}

