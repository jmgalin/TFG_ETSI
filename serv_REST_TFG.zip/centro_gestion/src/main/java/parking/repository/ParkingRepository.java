package parking.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import parking.entity.Parking;

public interface ParkingRepository extends JpaRepository<Parking, Long> {
    Parking findByLatitudeAndLongitude(Float latitude, Float longitude);
}

