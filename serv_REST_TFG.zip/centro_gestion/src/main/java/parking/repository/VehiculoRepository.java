package parking.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import parking.entity.Vehiculo;
import java.util.List;

public interface VehiculoRepository extends JpaRepository<Vehiculo, String> {

    List<Vehiculo> findByUsuarioDni(String dni);

    // Otros métodos de consulta si es necesario

}

