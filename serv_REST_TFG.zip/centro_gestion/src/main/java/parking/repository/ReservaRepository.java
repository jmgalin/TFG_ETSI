package parking.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import parking.entity.Parking;
import parking.entity.Reserva;
import parking.entity.Vehiculo;
import java.time.LocalDateTime;
import java.util.*;

public interface ReservaRepository extends JpaRepository<Reserva, Long> {
    List<Reserva> findByVehiculo_Matricula(String matricula);
	List<Reserva> findByParking_Id(Long parkingId);
	List<Reserva> findByVehiculoAndParkingAndFechaInicio(Vehiculo vehiculo, Parking parking, LocalDateTime fecha_inicio);
}

