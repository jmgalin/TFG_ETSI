package parking.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import parking.entity.Usuario;

public interface UsuarioRepository extends JpaRepository<Usuario, String> {
    // Puedes agregar consultas personalizadas aquí si es necesario
}
