package parking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.crypto.password.PasswordEncoder;

import parking.entity.Usuario;
import parking.repository.UsuarioRepository;

@RestController
@RequestMapping("/api/registro")
@CrossOrigin(origins = "*")
public class RegisterController {

    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public RegisterController(UsuarioRepository usuarioRepository, PasswordEncoder passwordEncoder) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @PostMapping()
    public ResponseEntity<String> registro(
            @RequestParam(name = "dni") String dni,
            @RequestParam(name = "nombre") String nombre,
            @RequestParam(name = "apellidos") String apellidos,
            @RequestParam(name = "contrasena") String contrasena,
            @RequestParam(name = "email") String email) {

        // Verificar si el usuario ya existe en la base de datos
        if (usuarioRepository.existsById(dni)) {
            return ResponseEntity.badRequest().body("El DNI del usuario ya existe");
        }

		// Encriptar la contraseña
        String contrasenaEncriptada = passwordEncoder.encode(contrasena);

        // Insertar el usuario en la base de datos
        Usuario nuevoUsuario = new Usuario();
        nuevoUsuario.setDni(dni);
        nuevoUsuario.setNombre(nombre);
        nuevoUsuario.setApellidos(apellidos);
        nuevoUsuario.setContrasena(contrasenaEncriptada);
        nuevoUsuario.setEmail(email);

        usuarioRepository.save(nuevoUsuario);

        System.out.println("Usuario registrado correctamente con dni: " + dni);
        return ResponseEntity.ok("Usuario registrado correctamente");
    }
}


