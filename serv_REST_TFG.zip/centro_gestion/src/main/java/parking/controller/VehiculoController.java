package parking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import parking.entity.Vehiculo;
import parking.entity.Usuario;
import parking.service.VehiculoService;
import parking.service.UsuarioService;

@RestController
@RequestMapping("/api/vehiculos")
public class VehiculoController {

    private final VehiculoService vehiculoService;
    private final UsuarioService usuarioService;

    @Autowired
    public VehiculoController(VehiculoService vehiculoService, UsuarioService usuarioService) {
        this.vehiculoService = vehiculoService;
        this.usuarioService = usuarioService;
    }

    @GetMapping()
    public List<Vehiculo> getVehiculosByUsuarioDni(@RequestParam String dni) {
        return vehiculoService.getVehiculosByUsuarioDni(dni);
    }

    @PostMapping()
	public ResponseEntity<String> registrarVehiculo(
        @RequestParam String matricula,
        @RequestParam String marca,
        @RequestParam String modelo,
        @RequestParam Integer plazas,
        @RequestParam String dni) {

    // Verificar si el vehículo ya existe en la base de datos
    if (vehiculoService.existeVehiculo(matricula, dni)) {
        return ResponseEntity.badRequest().body("El vehículo ya existe");
    }

    // Obtener el usuario asociado al DNI
    Usuario usuario = usuarioService.getUsuarioByDni(dni);

    // Crear un nuevo vehículo
    Vehiculo nuevoVehiculo = new Vehiculo(matricula, marca, modelo, plazas, usuario);

    // Insertar el vehículo en la base de datos
    vehiculoService.registrarVehiculo(nuevoVehiculo);

    System.out.println("Vehículo registrado correctamente con matricula: " + matricula);
    return ResponseEntity.ok("Vehículo registrado correctamente");
	}

	/*@PostMapping()
	public ResponseEntity<String> registrarVehiculo(
		@RequestParam String matricula,
		@RequestParam String marca,
		@RequestParam String modelo,
		@RequestParam Integer plazas,
		@RequestParam String dni) {

		// Verificar si el vehículo ya existe en la base de datos
		boolean vehiculoExistente = vehiculoService.existeVehiculo(matricula);

		if (vehiculoExistente) {
		    // Obtener el usuario asociado al DNI
		    Usuario usuario = usuarioService.getUsuarioByDni(dni);

		    // Obtener el vehículo existente por matrícula
		    Vehiculo vehiculo = vehiculoService.getByMatricula(matricula);

		    // Asociar el vehículo existente con el nuevo usuario
		    vehiculo.setUsuario(usuario);
		    vehiculoService.registrarVehiculo(vehiculo);

		    System.out.println("El vehículo se ha asociado correctamente al nuevo usuario.");
		    return ResponseEntity.ok("El vehículo se ha asociado correctamente al nuevo usuario.");
		} else {
		    // Obtener el usuario asociado al DNI
		    Usuario usuario = usuarioService.getUsuarioByDni(dni);

		    // Crear un nuevo vehículo
		    Vehiculo nuevoVehiculo = new Vehiculo(matricula, marca, modelo, plazas, usuario);

		    // Insertar el vehículo en la base de datos
		    vehiculoService.registrarVehiculo(nuevoVehiculo);

		    System.out.println("Vehículo registrado correctamente.");
		    return ResponseEntity.ok("Vehículo registrado correctamente");
		}
	}*/






    // Otros métodos del controlador según sea necesario

}



