package parking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.HttpStatus;

import parking.entity.Parking;
import parking.service.ParkingService;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Arrays;
import java.util.stream.Collectors;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/parking")
public class ParkingController {

    private final ParkingService parkingService;
	private final RestTemplate restTemplate;

    @Autowired
    public ParkingController(ParkingService parkingService, RestTemplate restTemplate) {
        this.parkingService = parkingService;
		this.restTemplate = restTemplate;
    }

    @GetMapping()
    public ResponseEntity<List<Object>> getAvailableParking() {
        List<Parking> availableParking = parkingService.getAllParking();

        List<Object> formattedResponse = availableParking.stream()
                .map(parking -> formatParkingInfo(parking))
                .collect(Collectors.toList());

        return ResponseEntity.ok(formattedResponse);
    }

    private Object formatParkingInfo(Parking parking) {
        Map<String, Object> parkingInfo = new HashMap<>();

        parkingInfo.put("id", parking.getId());
        parkingInfo.put("name", parking.getName());
        parkingInfo.put("chargeType", parking.getChargeType());
        parkingInfo.put("priceCurrency", parking.getPricecurrency());
        parkingInfo.put("priceRatePerMinute", parking.getPriceRatePerMinute());
        parkingInfo.put("location", Map.of(
                "coordinates", Arrays.asList(parking.getLongitude(), parking.getLatitude()),
                "type", parking.getType_Location()
        ));
        parkingInfo.put("totalSlotNumber", parking.getTotalSlotNumber());
        parkingInfo.put("availableSlotNumber", parking.getAvailableSlotNumber());
        parkingInfo.put("occupancy", (parking.getOccupancy()));
        parkingInfo.put("address", Map.of(
                "streetAddress", parking.getAddress(),
                "addressLocality", parking.getCity(),
                "addressCountry", parking.getCountry()
        ));
        parkingInfo.put("type", parking.getType_Parking());

        return parkingInfo;
    }
	
	//Lo he puesto de forma que sobre este método en la APP
	/*
	@GetMapping("/id")
    public ResponseEntity<List<Object>> getAvailableParking1() {
        List<Parking> availableParking = parkingService.getAllParking();

        List<Object> formattedResponse = availableParking.stream()
                .map(parking -> formatParkingInfo1(parking))
                .collect(Collectors.toList());

        return ResponseEntity.ok(formattedResponse);
    }

    private Object formatParkingInfo1(Parking parking) {
        // Construir la estructura del objeto según el formato deseado
        return Map.of(
                "id", parking.getId(),
                "name", parking.getName()
                // Agregar otras propiedades según sea necesario
        );
    }*/
	
	//Función que recoge los datos de los parkings cada 2 minutos
	@Scheduled(fixedRate = 120000) // Ejecutar cada 2 minutos (en milisegundos)
    public void updateParkingData() {
		//Parking 1
        String apiUrl = "http://localhost:8081/api/parking";
        Parking[] parkingArray = restTemplate.getForObject(apiUrl, Parking[].class);

        if (parkingArray != null) {
            List<Parking> parkingList = Arrays.asList(parkingArray);
            parkingService.saveAll(parkingList);
            System.out.println("Datos de parkings de la red actualizados correctamente");
        } else {
            System.out.println("Error al actualizar los datos de parkings de la red");
        }
    }

	@PostMapping()
	public ResponseEntity<String> crearNuevoParking(
		@RequestParam String type,
		@RequestParam String name,
		@RequestParam String category,
		@RequestParam String chargetype,
		@RequestParam String pricecurrency,
		@RequestParam Float pricerateperminute,
		@RequestParam Float latitude,
		@RequestParam Float longitude,
		@RequestParam String allowedvehicletype,
		@RequestParam String address,
		@RequestParam String city,
		@RequestParam String country,
		@RequestParam String postcode,
		@RequestParam Integer totalslotnumber,
		@RequestParam String maximumallowedheight,
		@RequestParam String maximumallowedwidth,
		@RequestParam String type_parking) {
		
		try{
			// Verificar si ya existe un parking con la misma latitud y longitud
			if (parkingService.existeParkingConLatitudYLongitud(latitude, longitude)) {
		        return ResponseEntity.badRequest().body("Ya existe un parking en esa ubicación.");
		    }
			
			// Obtener el máximo id actual
		    Long maxId = parkingService.getMaxId();
			//System.out.println("Valor maximo id:" + maxId);

		    // Incrementar el máximo id en uno para usarlo como el id del nuevo parking
		    Long nuevoId = maxId + 1;
			
			// Valores por defecto
			Integer availableslotnumber = totalslotnumber;
			Integer occupiedslotnumber = 0;
			Float occupancy = 0.0f;
			String type_location = "Point";
			

			Parking nuevoParking = new Parking(nuevoId, type, name, category, chargetype, pricecurrency,
				pricerateperminute, latitude, longitude, type_location, allowedvehicletype,
				address, city, country, postcode, totalslotnumber, availableslotnumber,
				occupiedslotnumber, occupancy, maximumallowedheight, maximumallowedwidth,
				type_parking);

			parkingService.registrarParking(nuevoParking);

			System.out.println("Se ha creado correctamente el nuevo parking con nombre: " + name);
			return ResponseEntity.ok("Se ha creado correctamente el nuevo parking con id: " + nuevoId);

		} catch (Exception e) {
		    // Manejo de errores
		    e.printStackTrace();
		    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Ha ocurrido un error al intentar crear el nuevo parking.");
		}
	}


}

