package parking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import parking.entity.Reserva;
import parking.entity.Vehiculo;
import parking.entity.Parking;
import parking.service.ReservaService;
import parking.service.VehiculoService;
import parking.service.ParkingService;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

import org.springframework.web.bind.annotation.CrossOrigin;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/reserva")
public class ReservaController {

    private final ReservaService reservaService;
    private final VehiculoService vehiculoService;
	private final ParkingService parkingService;
	
    @Autowired
    public ReservaController(ReservaService reservaService, VehiculoService vehiculoService, ParkingService parkingService) {
        this.reservaService = reservaService;
        this.vehiculoService = vehiculoService;
		this.parkingService = parkingService;
    }

    @PostMapping()
    public ResponseEntity<String> reservar(
            @RequestParam String vehiculo_matricula,
            @RequestParam Long parking_id,
            @RequestParam String fecha_inicio,
            @RequestParam String fecha_fin,
            @RequestParam(defaultValue = "false") Boolean confirmada) {

        // Buscar el vehículo por matrícula
        Vehiculo vehiculo = vehiculoService.getByMatricula(vehiculo_matricula);

		// Verificar si el vehículo existe
		if (vehiculo == null) {
		    return ResponseEntity.badRequest().body("El vehículo con matrícula " + vehiculo_matricula + " no está dado de alta en el sistema.");
		}


		// Buscar el parking por su id
        Parking parking = parkingService.getParkingById(parking_id);
	
		// Convertir las cadenas de fecha a objetos LocalDateTime
		LocalDateTime fechaInicio = LocalDateTime.parse(fecha_inicio + "T00:00:00");
		LocalDateTime fechaFin = LocalDateTime.parse(fecha_fin + "T23:59:59");

		// Verificar si ya existe una reserva para este vehículo y fecha de inicio en el mismo parking
		if (reservaService.existeReserva(vehiculo, parking, fechaInicio)) {
		    return ResponseEntity.badRequest().body("Ya existe una reserva para esta fecha y este vehículo en el mismo parking.");
		}

		//Calcular el precio de la reserva
		double precioTotal = calcularPrecioReserva(parking_id, fecha_inicio, fecha_fin);


        // Crear una nueva reserva
        Reserva nuevaReserva = new Reserva(vehiculo, parking, fechaInicio, fechaFin, confirmada, precioTotal);

        // Registrar la reserva en el servicio
        reservaService.registrarReserva(nuevaReserva);
		
		System.out.println("Se ha creado una reserva para la matricula: " + vehiculo_matricula + " en el parking con id: " + parking_id);
        return ResponseEntity.ok("Reserva creada exitosamente");
    }

	private double calcularPrecioReserva(Long parkingId, String fechaInicioStr, String fechaFinStr) {
		// Obtener el parking por su ID
		Parking parking = parkingService.getParkingById(parkingId);
		if (parking == null) {
		    throw new IllegalArgumentException("No se encontró el parking con el ID proporcionado");
		}

		// Convertir las cadenas de fecha a objetos LocalDateTime
		LocalDateTime fechaInicio = LocalDateTime.parse(fechaInicioStr + "T00:00:00");
		LocalDateTime fechaFin = LocalDateTime.parse(fechaFinStr + "T23:59:59");

		// Calcular los minutos totales de la reserva
		long minutosReserva = java.time.Duration.between(fechaInicio, fechaFin).toMinutes();

		// Calcular el precio multiplicando los minutos por el precio por minuto del parking
		double precioTotal = minutosReserva * parking.getPriceRatePerMinute();

		return precioTotal;
	}


	/*@GetMapping()
	public ResponseEntity<List<Map<String, Object>>> obtenerInformacionReserva(@RequestParam String matricula) {
		List<Reserva> reservas = reservaService.obtenerReservaPorMatricula(matricula);

		if (!reservas.isEmpty()) {
		    List<Map<String, Object>> responseList = new ArrayList<>();

		    for (Reserva reserva : reservas) {
		        Map<String, Object> response = new HashMap<>();
				response.put("reserva_id", reserva.getReservaId());
		        response.put("parking_id", reserva.getParking().getId());
		        response.put("fecha_inicio", reserva.getFechaInicio());
		        response.put("fecha_fin", reserva.getFechaFin());
		        response.put("confirmada", reserva.getConfirmada());
				response.put("precio_reserva", reserva.getPrecio_reserva());

		        responseList.add(response);
		    }

		    return ResponseEntity.ok(responseList);
		} else {
		    // No se encontraron reservas
			//Ver si devolver esto o no
		    return ResponseEntity.notFound().build();
		}
	}*/

	@GetMapping()
	public ResponseEntity<List<Map<String, Object>>> obtenerInformacionReserva(@RequestParam String matricula) {
		List<Reserva> reservas = reservaService.obtenerReservaPorMatricula(matricula);
		List<Map<String, Object>> responseList = new ArrayList<>();

		// Obtener la fecha actual sin tener en cuenta la hora
		LocalDate fechaActual = LocalDate.now();

		// Filtrar y mapear las reservas que no han finalizado aún
		reservas.stream()
		        .filter(reserva -> !reserva.getFechaFin().toLocalDate().isBefore(fechaActual))
		        .map(reserva -> {
		            Map<String, Object> response = new HashMap<>();
		            response.put("reserva_id", reserva.getReservaId());
		            response.put("parking_id", reserva.getParking().getId());
		            response.put("fecha_inicio", reserva.getFechaInicio());
		            response.put("fecha_fin", reserva.getFechaFin());
		            response.put("confirmada", reserva.getConfirmada());
		            response.put("precio_reserva", reserva.getPrecio_reserva());
		            return response;
		        })
		        .forEach(responseList::add);

		// Ordenar la lista de reservas por fecha de inicio ascendente y luego por fecha de inicio más reciente
		Collections.sort(responseList, (r1, r2) -> {
		    LocalDateTime fechaInicio1 = (LocalDateTime) r1.get("fecha_inicio");
		    LocalDateTime fechaInicio2 = (LocalDateTime) r2.get("fecha_inicio");
		    
		    // Primero ordenar por fecha de inicio ascendente
		    int compareByFechaInicio = fechaInicio1.compareTo(fechaInicio2);
		    if (compareByFechaInicio != 0) {
		        return compareByFechaInicio;
		    } else {
		        // Si las fechas de inicio son iguales, ordenar por fecha de inicio más reciente
		        LocalDateTime fechaFin1 = (LocalDateTime) r1.get("fecha_fin");
		        LocalDateTime fechaFin2 = (LocalDateTime) r2.get("fecha_fin");
		        return fechaInicio2.compareTo(fechaInicio1);
		    }
		});

		if (!responseList.isEmpty()) {
		    return ResponseEntity.ok(responseList);
		} else {
		    // No se encontraron reservas con la matricula dada
		    return ResponseEntity.notFound().build();
		}
	}



	
	@GetMapping("/{parkingId}")
	public ResponseEntity<List<Map<String, Object>>> obtenerInformacionReservaPorParking(@PathVariable Long parkingId) {
		List<Reserva> reservas = reservaService.obtenerReservaPorParkingId(parkingId);

		// Obtener la fecha actual sin tener en cuenta la hora
		LocalDate fechaActual = LocalDate.now();

		if (!reservas.isEmpty()) {
		    List<Map<String, Object>> responseList = new ArrayList<>();

			for (Reserva reserva : reservas) {
				// Obtener la fecha de fin de la reserva sin tener en cuenta la hora
				LocalDate fechaFinReserva = reserva.getFechaFin().toLocalDate();

				// Comparar solo el día, el mes y el año de la fecha de fin de la reserva con la fecha actual
				if (!fechaFinReserva.isBefore(fechaActual)) {
					Map<String, Object> response = new HashMap<>();
					response.put("reserva_id", reserva.getReservaId());
					response.put("matricula", reserva.getVehiculo().getMatricula());
					response.put("fecha_inicio", reserva.getFechaInicio());
					response.put("fecha_fin", reserva.getFechaFin());
					response.put("confirmada", reserva.getConfirmada());
					response.put("precio_reserva", reserva.getPrecio_reserva());

					responseList.add(response);
				}
			}

		    return ResponseEntity.ok(responseList);
		} else {
		    // No se encontró reserva para el parking dado
		    return ResponseEntity.notFound().build();
		}
	}

	/*@PostMapping("/confirm")
	public ResponseEntity<String> confirmar(
		    @RequestParam Long reserva_id) {

		// Buscar la reserva por su ID
		Reserva reserva = reservaService.obtenerReservaPorId(reserva_id);

		// Verificar si se encontró la reserva
		if (reserva != null) {
		    // Cambiar el estado de confirmada a true
		    reserva.setConfirmada(true);
		    
		    // Guardar la reserva actualizada en la base de datos
		    reservaService.registrarReserva(reserva);
	
			System.out.println("Se ha confirmado la reserva con id: " + reserva_id);
		    return ResponseEntity.ok("Reserva confirmada exitosamente");
		} else {
		    // No se encontró la reserva con el ID dado
		    return ResponseEntity.notFound().build();
		}
	}*/

	@PatchMapping("/confirmacion/{reserva_id}")
	public ResponseEntity<String> confirmar(
		    @PathVariable Long reserva_id,
		    @RequestBody Map<String, Boolean> requestBody) {

		// Obtener el valor de confirmada del cuerpo de la solicitud
		Boolean confirmada = requestBody.get("confirmada");

		// Buscar la reserva por su ID
		Reserva reserva = reservaService.obtenerReservaPorId(reserva_id);

		// Verificar si se encontró la reserva
		if (reserva != null) {
			if (confirmada == true){
				// Establecer el valor de confirmada true
				reserva.setConfirmada(confirmada);
				
				// Guardar la reserva actualizada en la base de datos
				reservaService.registrarReserva(reserva);

				System.out.println("Se ha confirmado la reserva con id: " + reserva_id);
				return ResponseEntity.ok("Reserva confirmada exitosamente");
			}else{
				// Establecer el valor de confirmada false
				reserva.setConfirmada(confirmada);
				
				// Guardar la reserva actualizada en la base de datos
				reservaService.registrarReserva(reserva);

				System.out.println("Se ha cancelado la confirmación de la reserva con id: " + reserva_id);
				return ResponseEntity.ok("Confirmación de reserva cancelada exitosamente");

			}
		} else {
		    // No se encontró la reserva con el ID dado
		    return ResponseEntity.notFound().build();
		}
	}

	/*@PostMapping("/noconfirm")
	public ResponseEntity<String> noconfirmar(
		    @RequestParam Long reserva_id) {

		// Buscar la reserva por su ID
		Reserva reserva = reservaService.obtenerReservaPorId(reserva_id);

		// Verificar si se encontró la reserva
		if (reserva != null) {
		    // Cambiar el estado de confirmada a false
		    reserva.setConfirmada(false);
		    
		    // Guardar la reserva actualizada en la base de datos
		    reservaService.registrarReserva(reserva);
			
			System.out.println("No confirmado en la reserva con id: " + reserva_id);
		    return ResponseEntity.ok("Reserva puesta en estado no confirmada");
		} else {
		    // No se encontró la reserva con el ID dado
		    return ResponseEntity.notFound().build();
		}
	}*/

	@DeleteMapping()
    public ResponseEntity<String> eliminarReserva(@RequestParam("idreserva") Long reserva_id) {
        // Buscar la reserva por su ID
        Reserva reserva = reservaService.obtenerReservaPorId(reserva_id);

        // Verificar si se encontró la reserva
        if (reserva != null) {
            // Eliminar la reserva
            reservaService.eliminarReserva(reserva);

			System.out.println("Se ha eliminado la reserva con id: " + reserva_id);
            return ResponseEntity.ok("Reserva eliminada exitosamente");
        } else {
            // No se encontró la reserva con el ID dado
            return ResponseEntity.notFound().build();
        }
    }


}


