package parking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.crypto.password.PasswordEncoder;

import parking.repository.UsuarioRepository;
import parking.entity.Usuario;

import java.util.Optional;

@RestController
@RequestMapping("/api/login")
@CrossOrigin(origins = "*")
public class LoginController {

    private final UsuarioRepository usuarioRepository;
	private final PasswordEncoder passwordEncoder;

    @Autowired
    public LoginController(UsuarioRepository usuarioRepository, PasswordEncoder passwordEncoder) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @PostMapping()
    public ResponseEntity<String> login(@RequestParam(name="dni") String dni,
                                       @RequestParam(name="contrasena") String contrasena) {
        Optional<Usuario> optionalLogin = usuarioRepository.findById(dni);
        if (optionalLogin.isPresent()) {
            Usuario usuario = optionalLogin.get();
            if (passwordEncoder.matches(contrasena, usuario.getContrasena())) {
                return new ResponseEntity<>("Login exitoso", HttpStatus.OK);
            }
        }
        return new ResponseEntity<>("Usuario o contraseña incorrectos", HttpStatus.UNAUTHORIZED);
    }
}


