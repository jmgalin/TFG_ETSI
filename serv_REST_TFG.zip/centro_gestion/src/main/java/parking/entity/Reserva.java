package parking.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@Table(name = "reservas")
public class Reserva implements Serializable{

    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long reserva_id;

    @ManyToOne
    @JoinColumn(name = "vehiculo_matricula", nullable = false)
    private Vehiculo vehiculo;

    @ManyToOne
    @JoinColumn(name = "parking_id", nullable = false)
    private Parking parking;
    
	@Column(name = "fecha_inicio", nullable = false)
    private LocalDateTime fechaInicio;
    private LocalDateTime fecha_fin;
    private Boolean confirmada;
    private Double precio_reserva;

    // Constructores

    public Reserva() {
    }

    public Reserva(Vehiculo vehiculo, Parking parking, LocalDateTime fechaInicio, LocalDateTime fecha_fin, Boolean confirmada, Double precio_reserva) {
        this.vehiculo = vehiculo;
        this.parking = parking;
        this.fechaInicio = fechaInicio;
        this.fecha_fin = fecha_fin;
        this.confirmada = confirmada;
		this.precio_reserva = precio_reserva;
    }

    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    public void setVehiculo(Vehiculo vehiculo) {
        this.vehiculo = vehiculo;
    }

    public Parking getParking() {
        return parking;
    }

    public void setParking(Parking parking) {
        this.parking = parking;
    }

    public LocalDateTime getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(LocalDateTime fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public LocalDateTime getFechaFin() {
        return fecha_fin;
    }

    public void setFechaFin(LocalDateTime fecha_fin) {
        this.fecha_fin = fecha_fin;
    }

    public Boolean getConfirmada() {
        return confirmada;
    }

    public void setConfirmada(Boolean confirmada) {
        this.confirmada = confirmada;
    }

	public Long getReservaId() {
        return reserva_id;
    }

    public void setReservaId(Long reserva_id) {
        this.reserva_id = reserva_id;
    }

    public double getPrecio_reserva() {
        return precio_reserva;
    }

    public void setPrecio_reserva(Double precio_reserva) {
        this.precio_reserva = precio_reserva;
    }

    // Otros métodos si es necesario

    // ...
}

