package parking.entity;

import javax.persistence.*;
import java.util.*;

@Entity
@Table(name = "vehiculo")
public class Vehiculo {

    
	@Id
    private String matricula;

    private String marca;
    private String modelo;
    private Integer plazas;

	@ManyToOne
    @JoinColumn(name = "usuarios_dni", nullable = false)
    private Usuario usuario;

    // Constructores

    public Vehiculo() {
    }

    public Vehiculo(String matricula, String marca, String modelo, Integer plazas, Usuario usuario) {
		this.matricula = matricula;
        this.marca = marca;
        this.modelo = modelo;
        this.plazas = plazas;
        this.usuario = usuario;
    }

    // Getters y Setters

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public Integer getPlazas() {
        return plazas;
    }

    public void setPlazas(Integer plazas) {
        this.plazas = plazas;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }


    // Otros métodos si es necesario

    // ...
}

