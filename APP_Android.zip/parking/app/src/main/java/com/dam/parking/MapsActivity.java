package com.dam.parking;

import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.dam.parking.databinding.ActivityMapsBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsBinding binding;
    private String json; // Mover la variable json aquí

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        // Realizar la petición para obtener datos de estacionamientos disponibles
        new GetParkingData().execute();

        // Botón Volver
        Button btnVolver = findViewById(R.id.button_volver_atras);
        btnVolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish(); // Cierra la actividad al hacer clic en Volver
            }
        });
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Agregar un listener para los clics en los marcadores
        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {
                // Obtener información del marcador
                String title = marker.getTitle();
                ParkingInfoDialog(title);
                return false;
            }
        });
    }

    private class GetParkingData extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... voids) {
            try {
                String url = Constants.API_URL + "/api/parking";
                URL urlObject = new URL(url);
                HttpURLConnection connection = (HttpURLConnection) urlObject.openConnection();

                // Configurar la conexión
                connection.setRequestMethod("GET");
                connection.setReadTimeout(10000);
                connection.setConnectTimeout(15000);

                // Obtener la respuesta
                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();
                    // Asignar el valor a la variable json
                    json = response.toString();

                    return json;
                } else {
                    return "Error en la petición";
                }
            } catch (IOException e) {
                e.printStackTrace();
                return "Error en la petición";
            }
        }

        @Override
        protected void onPostExecute(String response) {
            if (!response.equals("Error en la petición")) {
                showParkingLocations(response);
            }
        }
    }

    private void showParkingLocations(String json) {
        try {
            JSONArray parkingArray = new JSONArray(json);

            for (int i = 0; i < parkingArray.length(); i++) {
                JSONObject parkingObject = parkingArray.getJSONObject(i);

                // Obtener información del JSON
                String name = parkingObject.getString("name");
                double latitude = parkingObject.getJSONObject("location").getJSONArray("coordinates").getDouble(1);
                double longitude = parkingObject.getJSONObject("location").getJSONArray("coordinates").getDouble(0);
                String streetAddress = parkingObject.getJSONObject("address").getString("streetAddress");
                double occupancy = parkingObject.getDouble("occupancy") * 100;

                // Determinar el color del marcador según el nivel de ocupación
                float markerColor = getMarkerColor(occupancy);

                // Crear LatLng y agregar marcador al mapa con el color determinado
                LatLng parkingLocation = new LatLng(latitude, longitude);
                mMap.addMarker(new MarkerOptions()
                        .position(parkingLocation)
                        .title(streetAddress)
                        .snippet(name)
                        .icon(BitmapDescriptorFactory.defaultMarker(markerColor))); // Establecer el color del marcador
            }

            // Mover la cámara a la última posición
            if (parkingArray.length() > 0) {
                JSONObject lastParking = parkingArray.getJSONObject(parkingArray.length() - 1);
                double lastLatitude = lastParking.getJSONObject("location").getJSONArray("coordinates").getDouble(1);
                double lastLongitude = lastParking.getJSONObject("location").getJSONArray("coordinates").getDouble(0);
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(lastLatitude, lastLongitude), 10));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    // Método para determinar el color del marcador según el nivel de ocupación
    private float getMarkerColor(double occupancy) {
        if (occupancy < 75) {
            return BitmapDescriptorFactory.HUE_GREEN; // Verde
        } else if (occupancy >= 75 && occupancy < 90) {
            return BitmapDescriptorFactory.HUE_ORANGE; // Naranja
        } else {
            return BitmapDescriptorFactory.HUE_RED; // Rojo
        }
    }


    private void ParkingInfoDialog(String title) {
        // Buscar el estacionamiento correspondiente al título en el JSON original
        try {
            JSONArray parkingArray = new JSONArray(json); // Asegúrate de tener acceso a la variable json

            for (int i = 0; i < parkingArray.length(); i++) {
                JSONObject parkingObject = parkingArray.getJSONObject(i);
                String name = parkingObject.getString("name");
                String streetAddress = parkingObject.getJSONObject("address").getString("streetAddress").trim(); // Eliminar espacios alrededor del nombre

                if (streetAddress.equalsIgnoreCase(title.trim())) { // Comparación sin importar mayúsculas/minúsculas
                    // Encontramos el estacionamiento correspondiente
                    int availableSlots = parkingObject.getInt("availableSlotNumber");
                    double occupancy = parkingObject.getDouble("occupancy");
                    double priceRatePerMinute = parkingObject.getDouble("priceRatePerMinute");
                    String priceCurrency = parkingObject.getString("priceCurrency");

                    // Crear y mostrar el cuadro de diálogo con la información
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle(name)
                            .setMessage("Dirección: " + streetAddress + "\n" +
                                    "Plazas libres: " + availableSlots + "\n" +
                                    "Precio/minuto: " + priceRatePerMinute + " " + priceCurrency + "\n" +
                                    "Ocupación: " + occupancy * 100 + "%")
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    // No es necesario realizar ninguna acción al hacer clic en OK
                                }
                            });
                    builder.create().show();

                    break; // Salir del bucle una vez que se encuentre el estacionamiento
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

}

