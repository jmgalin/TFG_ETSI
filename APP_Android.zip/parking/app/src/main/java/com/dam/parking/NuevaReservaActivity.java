package com.dam.parking;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class NuevaReservaActivity extends AppCompatActivity {

    private Spinner spinnerMatricula;
    private Spinner spinnerIdParking;
    private EditText editTextFechaInicio;
    private EditText editTextFechaFin;
    private Button buttonRealizarReserva;

    private TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nueva_reserva);

        // Obtener la lista de matrículas guardadas en la aplicación
        App myApp = (App) getApplication();
        List<String> matriculas = myApp.getMatriculas();

        // Inicializar los componentes de la interfaz
        spinnerMatricula = findViewById(R.id.spinnerMatricula);
        spinnerIdParking = findViewById(R.id.spinnerIdParking);
        editTextFechaInicio = findViewById(R.id.editTextFechaIncio);
        editTextFechaFin = findViewById(R.id.editTextFechaFin);
        buttonRealizarReserva = findViewById(R.id.buttonRegister);

        // Configurar el adaptador para el Spinner de matrículas
        ArrayAdapter<String> matriculaAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, matriculas);
        matriculaAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerMatricula.setAdapter(matriculaAdapter);

        tv = findViewById(R.id.textViewExistingVehicle);

        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(NuevaReservaActivity.this, ReservasActivity.class));
            }
        });

        // Configurar el DatePicker para la fecha de inicio
        editTextFechaInicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mostrarDatePicker(editTextFechaInicio);
            }
        });

        // Configurar el DatePicker para la fecha de fin
        editTextFechaFin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mostrarDatePicker(editTextFechaFin);
            }
        });

        // Configurar el botón para realizar la reserva
        buttonRealizarReserva.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Obtener los valores seleccionados
                String matriculaSeleccionada = spinnerMatricula.getSelectedItem().toString();
                String idParkingSeleccionado = obtenerIdParkingSeleccionado();
                String fechaInicio = editTextFechaInicio.getText().toString();
                String fechaFin = editTextFechaFin.getText().toString();

                // Obtener la fecha actual
                Calendar calendar = Calendar.getInstance();
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH) + 1; // Los meses van de 0 a 11
                int day = calendar.get(Calendar.DAY_OF_MONTH);
                String fechaActual = String.format(Locale.getDefault(), "%04d-%02d-%02d", year, month, day);

                // Verificar que la fecha de inicio sea igual o posterior a la fecha actual
                if (fechaInicio.compareTo(fechaActual) < 0) {
                    // Mostrar mensaje de error
                    Toast.makeText(NuevaReservaActivity.this, "La fecha de inicio debe ser igual o posterior a la fecha actual", Toast.LENGTH_SHORT).show();
                    return; // Detener el proceso de reserva
                }

                // Verificar que la fecha final sea igual o posterior a la fecha de inicio
                if (fechaFin.compareTo(fechaInicio) < 0) {
                    // Mostrar mensaje de error
                    Toast.makeText(NuevaReservaActivity.this, "La fecha final debe ser igual o posterior a la fecha de inicio", Toast.LENGTH_SHORT).show();
                    return; // Detener el proceso de reserva
                }

                // Realizar la petición HTTP POST
                new RealizarReservaTask().execute(matriculaSeleccionada, idParkingSeleccionado, fechaInicio, fechaFin);
            }
        });


        // Obtener la lista de nombres de parkings mediante una tarea asíncrona
        new GetParkingsTask().execute();
    }

    private String obtenerIdParkingSeleccionado() {
        App myApp = (App) getApplication();
        int selectedPosition = spinnerIdParking.getSelectedItemPosition();
        List<String> ids = new ArrayList<>(myApp.getNombreIdParkingMap().values());
        return ids.get(selectedPosition);
    }

    private class RealizarReservaTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String matricula = params[0];
            String idParking = params[1];
            String fechaInicio = params[2];
            String fechaFin = params[3];

            String url = Constants.API_URL + "/api/reserva";

            HttpURLConnection connection = null;
            OutputStream outputStream = null;
            BufferedWriter writer = null;
            String responseString = "";

            try {
                URL urlObject = new URL(url);
                connection = (HttpURLConnection) urlObject.openConnection();
                connection.setRequestMethod("POST");
                connection.setReadTimeout(10000);
                connection.setConnectTimeout(15000);
                connection.setDoOutput(true);

                // Crear un mapa con los parámetros de la solicitud
                Map<String, Object> parameters = new HashMap<>();
                parameters.put("vehiculo_matricula", matricula);
                parameters.put("parking_id", idParking);
                parameters.put("fecha_inicio", fechaInicio);
                parameters.put("fecha_fin", fechaFin);

                // Escribir los parámetros en el cuerpo de la solicitud
                outputStream = connection.getOutputStream();
                writer = new BufferedWriter(new OutputStreamWriter(outputStream, StandardCharsets.UTF_8));
                writer.write(getPostDataString(parameters));
                writer.flush();

                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    // Leer la respuesta si es necesario
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;

                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    reader.close();

                    responseString = response.toString(); // Asignar la respuesta del servidor a la cadena de respuesta
                } else if (responseCode == HttpURLConnection.HTTP_BAD_REQUEST) {
                    // Si el código de respuesta es 400, ya existe una reserva para esta fecha y vehículo
                    return "Ya existe una reserva para esta fecha y este vehículo en el mismo parking";
                } else {
                    return "Error en la petición: " + responseCode;
                }
            } catch (IOException e) {
                e.printStackTrace();
                responseString = "Error en la petición";
            } finally {
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if (outputStream != null) {
                    try {
                        outputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if (connection != null) {
                    connection.disconnect();
                }
            }

            return responseString;
        }

        @Override
        protected void onPostExecute(String responseBody) {
            // Mostrar el mensaje devuelto por el servidor en un Toast
            Toast.makeText(NuevaReservaActivity.this, responseBody, Toast.LENGTH_SHORT).show();
        }
    }


    // Método para convertir el mapa de parámetros a una cadena de consulta
    private String getPostDataString(Map<String, Object> params) throws UnsupportedEncodingException {
        StringBuilder result = new StringBuilder();
        boolean first = true;

        for (Map.Entry<String, Object> entry : params.entrySet()) {
            if (first) {
                first = false;
            } else {
                result.append("&");
            }

            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(String.valueOf(entry.getValue()), "UTF-8"));
        }

        return result.toString();
    }


    private void mostrarDatePicker(final EditText editTextFecha) {
        // Configurar el DatePicker
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(NuevaReservaActivity.this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        // Formatear la fecha seleccionada
                        String fechaSeleccionada = String.format(Locale.getDefault(), "%04d-%02d-%02d", year, monthOfYear + 1, dayOfMonth);

                        // Mostrar la fecha en el EditText
                        editTextFecha.setText(fechaSeleccionada);
                    }
                }, year, month, dayOfMonth);

        // Establecer la fecha mínima permitida como la fecha actual
        datePickerDialog.getDatePicker().setMinDate(calendar.getTimeInMillis());

        // Mostrar el DatePicker
        datePickerDialog.show();
    }

    // Clase AsyncTask para obtener la lista de nombres de parkings
    private class GetParkingsTask extends AsyncTask<Void, Void, Map<String, String>> {
        @Override
        protected Map<String, String> doInBackground(Void... voids) {
            //String apiUrl = Constants.API_URL + "/api/parking/id";
            String apiUrl = Constants.API_URL + "/api/parking";

            try {
                URL url = new URL(apiUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setReadTimeout(10000);
                connection.setConnectTimeout(15000);

                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;

                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    reader.close();

                    return parseParkingMap(response.toString());
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Map<String, String> nombreIdParkingMap) {
            if (nombreIdParkingMap != null) {
                // Guardar el mapa de nombres e IDs de parkings en la instancia de la aplicación
                App myApp = (App) getApplication();
                myApp.setNombreIdParkingMap(nombreIdParkingMap);

                // Configurar el adaptador para el Spinner de parkings
                List<String> nombresParkings = new ArrayList<>(nombreIdParkingMap.keySet());
                ArrayAdapter<String> idParkingAdapter = new ArrayAdapter<>(NuevaReservaActivity.this, android.R.layout.simple_spinner_item, nombresParkings);
                idParkingAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerIdParking.setAdapter(idParkingAdapter);
            }
        }

        private Map<String, String> parseParkingMap(String json) {
            try {
                JSONArray jsonArray = new JSONArray(json);
                Map<String, String> nombreIdParkingMap = new HashMap<>();

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject parkingObject = jsonArray.getJSONObject(i);
                    int id = parkingObject.getInt("id");
                    String name = parkingObject.getString("name");

                    nombreIdParkingMap.put(name, String.valueOf(id));
                }

                return nombreIdParkingMap;
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return null;
        }
    }
}

