package com.dam.parking;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {

    EditText edDNI, edNombre, edApellidos, edEmail, edContrasena, edConfirm;
    Button btn;
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        edDNI = findViewById(R.id.editTextDNI);
        edNombre = findViewById(R.id.editTextNombre);
        edApellidos = findViewById(R.id.editTextApellidos);
        edEmail = findViewById(R.id.editTextRegEmail);
        edContrasena = findViewById(R.id.editTextRegContrasena);
        edConfirm = findViewById(R.id.editTextRegConfirmContrasena);

        btn = findViewById(R.id.buttonRegister);
        tv = findViewById(R.id.textViewExistingUser);

        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String dni = edDNI.getText().toString();
                String nombre = edNombre.getText().toString();
                String apellidos = edApellidos.getText().toString();
                String email = edEmail.getText().toString();
                String contrasena = edContrasena.getText().toString();
                String confirm = edConfirm.getText().toString();

                if (dni.length() == 0 || nombre.length() == 0 || apellidos.length() == 0 ||
                        email.length() == 0 || contrasena.length() == 0) {
                    Toast.makeText(getApplicationContext(), "Rellene todos los campos", Toast.LENGTH_SHORT).show();
                } else {
                    if (contrasena.equals(confirm)) {
                        new RegisterTask().execute(dni, nombre, apellidos, contrasena, email);
                    } else {
                        Toast.makeText(getApplicationContext(), "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private class RegisterTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String dni = params[0];
            String nombre = params[1];
            String apellidos = params[2];
            String contrasena = params[3];
            String email = params[4];

            String url = Constants.API_URL + "/api/registro";

            HttpURLConnection connection = null;
            OutputStream outputStream = null;
            BufferedWriter writer = null;
            String responseString = "";

            try {
                URL urlObject = new URL(url);
                connection = (HttpURLConnection) urlObject.openConnection();
                connection.setRequestMethod("POST");
                connection.setReadTimeout(10000);
                connection.setConnectTimeout(15000);
                connection.setDoOutput(true);

                // Crear un mapa con los parámetros de la solicitud
                Map<String, String> parameters = new HashMap<>();
                parameters.put("dni", dni);
                parameters.put("nombre", nombre);
                parameters.put("apellidos", apellidos);
                parameters.put("contrasena", contrasena);
                parameters.put("email", email);

                // Escribir los parámetros en el cuerpo de la solicitud
                outputStream = connection.getOutputStream();
                writer = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                writer.write(getPostDataString(parameters));
                writer.flush();

                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    // Leer la respuesta si es necesario
                    // ...

                    responseString = "Usuario registrado correctamente";  // Modificar según la respuesta real del servidor
                } else if (responseCode == HttpURLConnection.HTTP_BAD_REQUEST) {
                    // Leer el cuerpo de la respuesta cuando el código de respuesta es 400
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();
                    return response.toString();
                } else {
                    return "Error en la petición: " + responseCode;
                }
            } catch (IOException e) {
                e.printStackTrace();
                responseString = "Error en la petición";
            } finally {
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if (outputStream != null) {
                    try {
                        outputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if (connection != null) {
                    connection.disconnect();
                }
            }

            return responseString;
        }

        @Override
        protected void onPostExecute(String responseBody) {
            Toast.makeText(RegisterActivity.this, responseBody, Toast.LENGTH_SHORT).show();
        }
    }

    private String getPostDataString(Map<String, String> params) throws IOException {
        StringBuilder result = new StringBuilder();
        boolean first = true;

        for (Map.Entry<String, String> entry : params.entrySet()) {
            if (first) {
                first = false;
            } else {
                result.append("&");
            }

            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
        }

        return result.toString();
    }
}
