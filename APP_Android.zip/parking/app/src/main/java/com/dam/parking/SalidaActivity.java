package com.dam.parking;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.Result;
import com.journeyapps.barcodescanner.BarcodeCallback;
import com.journeyapps.barcodescanner.BarcodeResult;
import com.journeyapps.barcodescanner.CompoundBarcodeView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SalidaActivity extends AppCompatActivity {

    private CompoundBarcodeView barcodeView;
    private Spinner spinnerMatriculas;
    private ArrayAdapter<String> matriculaAdapter;
    private String matriculaSeleccionada;

    private Button btnPagar; // Declarar el botón


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_salida);

        // Obtener la lista de matrículas guardadas en la aplicación
        App myApp = (App) getApplication();
        String dni = myApp.getDni();

        // Botón Volver
        Button btnVolver = findViewById(R.id.button_volver_salida);
        btnVolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(SalidaActivity.this, HomeActivity.class));
            }
        });

        // Inicializar el botón y desactivarlo
        btnPagar = findViewById(R.id.button_pagar);
        btnPagar.setEnabled(false); // Desactivar el botón al principio
        // Iniciar la actividad PagoActivity
        btnPagar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(SalidaActivity.this, PagoActivity.class));
            }
        });

        spinnerMatriculas = findViewById(R.id.spinner_matriculas);  // Agregado: Inicializa el Spinner

        barcodeView = findViewById(R.id.barcode_scanner);

        // Configurar el escáner QR
        barcodeView.decodeSingle(new BarcodeCallback() {
            @Override
            public void barcodeResult(BarcodeResult result) {
                // Procesar el resultado del escaneo aquí
                String scannedText = result.getText();
                AlertDialog.Builder builder = new AlertDialog.Builder(SalidaActivity.this);
                builder.setMessage("¿Desea confirmar la salida del vehículo con la matrícula "+matriculaSeleccionada+ "?")
                        .setCancelable(false)
                        .setPositiveButton("Sí", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                                // Almacenar la matricula seleccionada
                                App myApp111 = (App) getApplication();
                                myApp111.setDireccionurl(scannedText);

                                // Si el usuario hace clic en "Sí", enviar la solicitud POST
                                realizarSolicitudPOST(scannedText + "/api/parking/salida", matriculaSeleccionada);
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // Si el usuario hace clic en "No", cancelar la acción
                                dialog.cancel();
                            }
                        });
                AlertDialog alert = builder.create();
                alert.show();
            }

            @Override
            public void possibleResultPoints(List<com.google.zxing.ResultPoint> resultPoints) {
                // No es necesario hacer nada aquí
            }
        });

        // Configurar un listener para el Spinner para capturar la matrícula seleccionada
        spinnerMatriculas.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                // Almacena la matrícula seleccionada
                matriculaSeleccionada = matriculaAdapter.getItem(position);


            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // Puedes manejar algo aquí si no se selecciona nada
            }
        });

        // Realizar la solicitud para obtener las matrículas asociadas al DNI
        //String apiUrlVehiculos = Constants.API_URL + "/api/vehiculos?dni=" + dni;
        new GetVehiculosTask().execute(dni);

    }

    @Override
    protected void onResume() {
        super.onResume();
        barcodeView.resume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        barcodeView.pause();
    }

    private void realizarSolicitudPOST(String apiUrl, String matricula) {
        new RealizarSolicitudPOSTTask().execute(apiUrl, matricula);
    }

    private class RealizarSolicitudPOSTTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String apiUrl = params[0];
            String matricula = params[1];

            // Almacenar la matricula seleccionada
            App myApp11 = (App) getApplication();
            myApp11.setMatriculaseleccionada(matricula);


            try {
                URL url = new URL(apiUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();

                // Configurar la conexión
                connection.setRequestMethod("POST");
                connection.setReadTimeout(10000);
                connection.setConnectTimeout(15000);
                connection.setDoOutput(true);

                // Crear un mapa con los parámetros de la solicitud
                Map<String, Object> parameters = new HashMap<>();
                parameters.put("matricula", matricula);

                // Escribir los parámetros en el cuerpo de la solicitud
                OutputStream outputStream = connection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream, StandardCharsets.UTF_8));
                writer.write(getPostDataString(parameters));
                writer.flush();
                writer.close();

                // Obtener la respuesta
                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;


                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();
                    return response.toString();
                } else if (responseCode == HttpURLConnection.HTTP_BAD_REQUEST) {
                    // Leer el cuerpo de la respuesta cuando el código de respuesta es 400
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();
                    return response.toString();
                } else {
                    return "Error en la petición: " + responseCode;
                }
            } catch (IOException e) {
                e.printStackTrace();
                return "Error en la petición";
            }
        }

        @Override
        protected void onPostExecute(String responseBody) {

            // Verificar si la respuesta del servidor es la deseada
            String mensajeDeseado = responseBody.substring(0, responseBody.indexOf("con matrícula"));

            /*String precioString = responseBody.replaceAll(".*precio: ([\\d.]+).*", "$1");

            // Convertimos el precio a tipo double
            double precio = Double.parseDouble(precioString);

            //Log.e("TAG", "Precio obtenido en la petición HTTP: " + precio);

            // Guardar el precio en la instancia de la aplicación
            App myApp1 = (App) getApplication();
            myApp1.setPrecio(precio);
               */
            //Log.e("TAG", "Precio obtenido desde la aplicación: " + myApp1.getPrecio());

            if (mensajeDeseado.trim().equals("Salida registrada correctamente")) {

                String precioString = responseBody.replaceAll(".*precio: ([\\d.]+).*", "$1");

                // Convertimos el precio a tipo double
                double precio = Double.parseDouble(precioString);

                //Log.e("TAG", "Precio obtenido en la petición HTTP: " + precio);

                // Guardar el precio en la instancia de la aplicación
                App myApp1 = (App) getApplication();
                myApp1.setPrecio(precio);

                // Activar el botón después de recibir una respuesta exitosa
                btnPagar.setEnabled(true);

                // Configurar un listener para el botón que inicie la actividad PagoActivity
                btnPagar.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        startActivity(new Intent(SalidaActivity.this, PagoActivity.class));
                    }
                });
            }

            Toast.makeText(SalidaActivity.this, responseBody, Toast.LENGTH_SHORT).show();
        }


        // Método para convertir los parámetros en formato de cadena para el cuerpo de la solicitud
        private String getPostDataString(Map<String, Object> params) throws UnsupportedEncodingException {
            StringBuilder result = new StringBuilder();
            boolean first = true;
            for (Map.Entry<String, Object> entry : params.entrySet()) {
                if (first) {
                    first = false;
                } else {
                    result.append("&");
                }
                result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
                result.append("=");
                result.append(URLEncoder.encode(String.valueOf(entry.getValue()), "UTF-8"));
            }
            return result.toString();
        }
    }

    private class GetVehiculosTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String dni = params[0];
            try {
                String apiUrl = Constants.API_URL + "/api/vehiculos?dni=" + dni;
                URL url = new URL(apiUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();

                // Configurar la conexión
                connection.setRequestMethod("GET");
                connection.setReadTimeout(10000);
                connection.setConnectTimeout(15000);

                // Obtener la respuesta
                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();
                    return response.toString();
                } else {
                    return "Error en la petición";
                }
            } catch (IOException e) {
                e.printStackTrace();
                return "Error en la petición";
            }
        }

        @Override
        protected void onPostExecute(String response) {
            if (!response.equals("Error en la petición")) {
                mostrarListaMatriculas(response);
            }
        }
    }

    private void mostrarListaMatriculas(String json) {
        try {
            JSONArray vehiculosArray = new JSONArray(json);
            List<String> matriculas = new ArrayList<>();

            for (int i = 0; i < vehiculosArray.length(); i++) {
                JSONObject vehiculoObject = vehiculosArray.getJSONObject(i);
                String matricula = vehiculoObject.getString("matricula");

                // Agregar cada matrícula a la lista
                matriculas.add(matricula);
            }

            // Guardar la lista de matrículas en la instancia de la aplicación
            App myApp = (App) getApplication();
            myApp.setMatriculas(matriculas);

            // Configurar el adaptador para el Spinner
            matriculaAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, matriculas);
            matriculaAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnerMatriculas.setAdapter(matriculaAdapter);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

}






