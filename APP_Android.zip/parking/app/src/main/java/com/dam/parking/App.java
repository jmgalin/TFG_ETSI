package com.dam.parking;

import android.app.Application;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class App extends Application {
    private String dni;

    private String matriculaseleccionada;

    private String direccionurl;

    private Double precio;
    private List<String> matriculas = new ArrayList<>();

    private List<String> nombreparkings = new ArrayList<>();

    private List<String> idreservas = new ArrayList<>();

    private Map<String, String> nombreIdParkingMap = new HashMap<>();

    public Map<String, String> getNombreIdParkingMap() {
        return nombreIdParkingMap;
    }

    public void setNombreIdParkingMap(Map<String, String> nombreIdParkingMap) {
        this.nombreIdParkingMap = nombreIdParkingMap;
    }

    public String getIdParkingByNombre(String nombre) {
        return nombreIdParkingMap.get(nombre);
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getMatriculaseleccionada() {
        return matriculaseleccionada;
    }

    public void setMatriculaseleccionada(String matriculaseleccionada) {
        this.matriculaseleccionada = matriculaseleccionada;
    }

    public String getDireccionurl() {
        return direccionurl;
    }

    public void setDireccionurl(String direccionurl) {
        this.direccionurl = direccionurl;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public List<String> getMatriculas() {
        return matriculas;
    }

    public void setMatriculas(List<String> matriculas) {
        this.matriculas = matriculas;
    }

    public void agregarMatricula(String matricula) {
        this.matriculas.add(matricula);
    }

    public List<String> getNombresParkings() {
        return nombreparkings;
    }

    public void setNombresParkings(List<String> parkings) {
        this.nombreparkings = nombreparkings;
    }

    public void setReservaId(List<String> idreservas) {
        this.idreservas = idreservas;
    }

    public List<String> getReservaId() {
        return idreservas;
    }


}
