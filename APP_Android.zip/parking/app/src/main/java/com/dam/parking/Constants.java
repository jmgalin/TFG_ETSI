package com.dam.parking;

//para definir constantes aqui como la URL
public class Constants {
    public static final String API_URL = "http://192.168.118.129:8080";
}
