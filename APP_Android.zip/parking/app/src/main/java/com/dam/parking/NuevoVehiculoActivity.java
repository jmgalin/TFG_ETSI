package com.dam.parking;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

public class NuevoVehiculoActivity extends AppCompatActivity {

    EditText edMatricula, edMarca, edModelo, edNumPlazas;
    Button btn;
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nuevo_vehiculo);

        edMatricula = findViewById(R.id.editTextMatricula);
        edMarca = findViewById(R.id.editTextMarca);
        edModelo = findViewById(R.id.editTextModelo);
        edNumPlazas = findViewById(R.id.editTextNumPlazas);

        btn = findViewById(R.id.buttonRegister);
        tv = findViewById(R.id.textViewExistingVehicle);

        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(NuevoVehiculoActivity.this, VehiculosActivity.class));
            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String matricula = edMatricula.getText().toString();
                String marca = edMarca.getText().toString();
                String modelo = edModelo.getText().toString();
                String numplazas = edNumPlazas.getText().toString();

                // Obtener dni del usuario que ha iniciado sesion
                App myApp = (App) getApplication();
                String dni = myApp.getDni();

                if (matricula.length() == 0 || marca.length() == 0 || modelo.length() == 0 ||
                        numplazas.length() == 0) {
                    Toast.makeText(getApplicationContext(), "Rellene todos los campos", Toast.LENGTH_SHORT).show();
                } else {
                    new RegisterTask().execute(matricula, marca, modelo, numplazas, dni);
                }
            }
        });
    }

    private class RegisterTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String matricula = params[0];
            String marca = params[1];
            String modelo = params[2];
            int numplazas = Integer.parseInt(params[3]);  // Convertir a int
            String dni = params[4];

            //String url = Constants.API_URL + "/api/vehiculos/registro";
            String url = Constants.API_URL + "/api/vehiculos";

            HttpURLConnection connection = null;
            OutputStream outputStream = null;
            BufferedWriter writer = null;
            String responseString = "";

            try {
                URL urlObject = new URL(url);
                connection = (HttpURLConnection) urlObject.openConnection();
                connection.setRequestMethod("POST");
                connection.setReadTimeout(10000);
                connection.setConnectTimeout(15000);
                connection.setDoOutput(true);

                // Crear un mapa con los parámetros de la solicitud
                Map<String, Object> parameters = new HashMap<>();
                parameters.put("dni", dni);
                parameters.put("matricula", matricula);
                parameters.put("marca", marca);
                parameters.put("modelo", modelo);
                parameters.put("plazas", numplazas);

                // Escribir los parámetros en el cuerpo de la solicitud
                outputStream = connection.getOutputStream();
                writer = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                writer.write(getPostDataString(parameters));
                writer.flush();

                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    // Leer la respuesta si es necesario
                    // ...

                    responseString = "Vehiculo registrado correctamente";  // Modificar según la respuesta real del servidor
                } else {
                    responseString = "El vehículo ya existe";
                }
            } catch (IOException e) {
                e.printStackTrace();
                responseString = "Error en la petición";
            } finally {
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if (outputStream != null) {
                    try {
                        outputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if (connection != null) {
                    connection.disconnect();
                }
            }

            return responseString;
        }

        @Override
        protected void onPostExecute(String responseBody) {
            Toast.makeText(NuevoVehiculoActivity.this, responseBody, Toast.LENGTH_SHORT).show();
        }
    }

    private String getPostDataString(Map<String, Object> params) throws IOException {
        StringBuilder result = new StringBuilder();
        boolean first = true;

        for (Map.Entry<String, Object> entry : params.entrySet()) {
            if (first) {
                first = false;
            } else {
                result.append("&");
            }

            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(String.valueOf(entry.getValue()), "UTF-8"));
        }

        return result.toString();
    }
}