package com.dam.parking;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReservasActivity extends AppCompatActivity {

    private ListView listViewReservas;

    List<String> reservas = new ArrayList<>();
    private ArrayAdapter<String> reservaAdapter;
    private Spinner spinnerMatriculas;
    private ArrayAdapter<String> matriculaAdapter;
    private String matriculaSeleccionada;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservas);

        listViewReservas = findViewById(R.id.list_view_reservas);
        spinnerMatriculas = findViewById(R.id.spinner_matriculas);  // Agregado: Inicializa el Spinner

        // Obtener la lista de matrículas guardadas en la aplicación
        App myApp = (App) getApplication();
        String dni = myApp.getDni();

        // Configurar un listener para el Spinner para capturar la matrícula seleccionada
        spinnerMatriculas.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                // Almacena la matrícula seleccionada
                matriculaSeleccionada = matriculaAdapter.getItem(position);

                // Luego, realiza tu solicitud con la matrícula seleccionada
                String apiUrl = Constants.API_URL + "/api/reserva?matricula=" + matriculaSeleccionada;
                new GetReservasTask().execute(apiUrl);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // Puedes manejar algo aquí si no se selecciona nada
            }
        });

        // Botón Volver
        Button btnVolver = findViewById(R.id.button_volver_reservas);
        btnVolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ReservasActivity.this, HomeActivity.class));
            }
        });

        // Botón Agregar Vehículo
        Button btnNuevaReserva = findViewById(R.id.button_nueva_reserva);
        btnNuevaReserva.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ReservasActivity.this, NuevaReservaActivity.class));
            }
        });

        // Realizar la solicitud para obtener las matrículas asociadas al DNI
        //String apiUrlVehiculos = Constants.API_URL + "/api/vehiculos/usuario?dni=" + dni;
        new GetVehiculosTask().execute(dni);

        // Realizar la solicitud para obtener el mapa de nombres e IDs de parkings
        new GetParkingsTask().execute();
    }

    private class GetVehiculosTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String dni = params[0];
            try {
                String apiUrl = Constants.API_URL + "/api/vehiculos?dni=" + dni;
                URL url = new URL(apiUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();

                // Configurar la conexión
                connection.setRequestMethod("GET");
                connection.setReadTimeout(10000);
                connection.setConnectTimeout(15000);

                // Obtener la respuesta
                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();
                    return response.toString();
                } else {
                    return "Error en la petición";
                }
            } catch (IOException e) {
                e.printStackTrace();
                return "Error en la petición";
            }
        }

        @Override
        protected void onPostExecute(String response) {
            if (!response.equals("Error en la petición")) {
                mostrarListaMatriculas(response);
            }
        }
    }

    private void mostrarListaMatriculas(String json) {
        try {
            JSONArray vehiculosArray = new JSONArray(json);
            List<String> matriculas = new ArrayList<>();

            for (int i = 0; i < vehiculosArray.length(); i++) {
                JSONObject vehiculoObject = vehiculosArray.getJSONObject(i);
                String matricula = vehiculoObject.getString("matricula");

                // Agregar cada matrícula a la lista
                matriculas.add(matricula);
            }

            // Guardar la lista de matrículas en la instancia de la aplicación
            App myApp = (App) getApplication();
            myApp.setMatriculas(matriculas);

            // Configurar el adaptador para el Spinner
            matriculaAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, matriculas);
            matriculaAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnerMatriculas.setAdapter(matriculaAdapter);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private class GetReservasTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String apiUrl = params[0];
            try {
                URL url = new URL(apiUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();

                // Configurar la conexión
                connection.setRequestMethod("GET");
                connection.setReadTimeout(10000);
                connection.setConnectTimeout(15000);

                // Obtener la respuesta
                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();
                    return response.toString();
                }else {
                    return "Error en la petición: " + responseCode;
                }
            } catch (IOException e) {
                e.printStackTrace();
                return "Error en la petición";
            }
        }

        @Override
        protected void onPostExecute(String response) {
            if (!response.equals("Error en la petición")) {
                mostrarListaReservas(response);
            }else{
                mostrarListaReservasVacia();
            }
        }
    }

    private String formatearFecha(String fecha) {
        // Eliminar la "T"
        fecha = fecha.replace("T", " ");
        return fecha;
    }

    private void mostrarListaReservasVacia() {
        List<String> reservasVacias = new ArrayList<>();
        reservasVacias.add("No hay reservas para esta matrícula.");

        // Utiliza el mismo adaptador para la lista de reservas, pero asigna los datos de manera diferente
        reservaAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, reservasVacias);
        listViewReservas.setAdapter(reservaAdapter);
    }


    private void mostrarListaReservas(String json) {
        try {
            JSONArray reservasArray = new JSONArray(json);
            List<String> reservas = new ArrayList<>();
            List<String> idReservas = new ArrayList<>();

            // Obtener el mapa de nombres e IDs de parkings de la instancia de la aplicación
            App myApp1 = (App) getApplication();
            Map<String, String> nombreIdParkingMap = myApp1.getNombreIdParkingMap();


            if (reservasArray.length() > 0) {
                for (int i = 0; i < reservasArray.length(); i++) {
                    JSONObject reservaObject = reservasArray.getJSONObject(i);
                    String idReserva = reservaObject.getString("reserva_id"); // Obtener el ID de la reserva
                    String fechaInicio = formatearFecha(reservaObject.getString("fecha_inicio"));
                    String fechaFin = formatearFecha(reservaObject.getString("fecha_fin"));
                    String parkingId = reservaObject.getString("parking_id");
                    Double precioReserva = reservaObject.getDouble("precio_reserva");
                    Boolean confirmada = reservaObject.getBoolean("confirmada");

                    // Convertir el valor booleano a una cadena "Sí" o "No"
                    String confirmadaStr = confirmada ? "Sí" : "No";

                    // Obtener el nombre del parking utilizando el mapa de nombres e IDs de parkings
                    String nombreParking = nombreIdParkingMap.get(parkingId);

                    String reservaInfo = "Inicio Reserva: " + fechaInicio + "\nFin Reserva: " + fechaFin + "\nParking: " + nombreParking + "\nPrecio Reserva: " + precioReserva + " €" + "\nConfirmada: " + confirmadaStr;

                    // Agregar el ID de reserva a la lista de la clase App
                    idReservas.add(idReserva);

                    reservas.add(reservaInfo);
                }

                App myApp = (App) getApplication();
                myApp.setReservaId(idReservas);

                // Configurar el adaptador para la lista de reservas
                reservaAdapter = new ArrayAdapter<String>(this, R.layout.list_item_reserva, R.id.text_view_reserva_info, reservas) {
                    @NonNull
                    @Override
                    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                        View itemView = convertView;
                        if (itemView == null) {
                            LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                            itemView = inflater.inflate(R.layout.list_item_reserva, parent, false);
                        }

                        // Obtener la reserva en esta posición
                        String reserva = getItem(position);

                        // Obtener referencias a las vistas en el diseño
                        TextView textViewReservaInfo = itemView.findViewById(R.id.text_view_reserva_info);
                        Button buttonCancelarReserva = itemView.findViewById(R.id.button_cancelar_reserva);

                        // Establecer el texto de la reserva en el TextView
                        textViewReservaInfo.setText(reserva);

                        // Configurar el clic del botón para cancelar la reserva
                        buttonCancelarReserva.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                String idReserva = idReservas.get(position); // Obtener el ID de reserva correspondiente al botón clicado
                                mostrarConfirmacionCancelacion(idReserva);
                            }
                        });

                        return itemView;
                    }
                };

                listViewReservas.setAdapter(reservaAdapter);

                // Agregar el botón de cancelar reserva al hacer clic en cada elemento de la lista
                listViewReservas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        String idReserva = idReservas.get(position); // Obtener el ID de reserva correspondiente al elemento clicado
                        mostrarConfirmacionCancelacion(idReserva);
                    }
                });

            } else {
                // Si no hay reservas disponibles, mostrar el mensaje adecuado
                mostrarListaReservasVacia();
            }


        } catch (JSONException e) {
            e.printStackTrace();
            mostrarListaReservasVacia();
        }
    }


    private void mostrarConfirmacionCancelacion(String idReserva) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("¿Estás seguro de que quieres cancelar esta reserva?")
                .setCancelable(false)
                .setPositiveButton("Sí", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        cancelarReserva(idReserva);
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

    // Cambios en cancelarReserva()
    private void cancelarReserva(String idReserva) {
        // Realizar la solicitud para cancelar la reserva con el ID de reserva proporcionado
        String apiUrl = Constants.API_URL + "/api/reserva"; // URL base del endpoint
        new CancelarReservaTask().execute(apiUrl, idReserva); // Pasar el ID de reserva como parámetro
    }


    private class CancelarReservaTask extends AsyncTask<String, Void, Boolean> {
        @Override
        protected Boolean doInBackground(String... params) {
            String apiUrl = params[0];
            String idReserva = params[1];

            try {
                URL url = new URL(apiUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();

                // Configurar la conexión
                connection.setRequestMethod("DELETE");
                connection.setConnectTimeout(15000);
                connection.setReadTimeout(15000);

                // Configurar el cuerpo de la solicitud
                String requestBody = "idreserva=" + idReserva; // Formatear el cuerpo con el ID de reserva
                connection.setDoOutput(true);
                connection.getOutputStream().write(requestBody.getBytes("UTF-8"));

                // Obtener la respuesta
                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    return true;
                } else {
                    return false;
                }
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean success) {
            if (success) {
                Toast.makeText(ReservasActivity.this, "Reserva cancelada correctamente", Toast.LENGTH_SHORT).show();
                // Actualizar la lista de reservas después de cancelar una reserva
                String apiUrl = Constants.API_URL + "/api/reserva?matricula=" + matriculaSeleccionada;
                new GetReservasTask().execute(apiUrl);
            } else {
                Toast.makeText(ReservasActivity.this, "Error al cancelar la reserva", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Clase AsyncTask para obtener la lista de nombres de parkings
    private class GetParkingsTask extends AsyncTask<Void, Void, Map<String, String>> {
        @Override
        protected Map<String, String> doInBackground(Void... voids) {
            //String apiUrl = Constants.API_URL + "/api/parking/id";
            String apiUrl = Constants.API_URL + "/api/parking";

            try {
                URL url = new URL(apiUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setReadTimeout(10000);
                connection.setConnectTimeout(15000);

                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;

                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    reader.close();

                    return parseParkingMap(response.toString());
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Map<String, String> nombreIdParkingMap) {
            if (nombreIdParkingMap != null) {
                // Guardar el mapa de nombres e IDs de parkings en la instancia de la aplicación
                App myApp = (App) getApplication();
                myApp.setNombreIdParkingMap(nombreIdParkingMap);

            }
        }

        private Map<String, String> parseParkingMap(String json) {
            try {
                JSONArray jsonArray = new JSONArray(json);
                Map<String, String> nombreIdParkingMap = new HashMap<>();

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject parkingObject = jsonArray.getJSONObject(i);
                    int id = parkingObject.getInt("id");
                    String name = parkingObject.getString("name");

                    // Cambiar la asignación para que el nombre del parking sea el valor
                    nombreIdParkingMap.put(String.valueOf(id), name);
                }

                return nombreIdParkingMap;
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return null;
        }

    }

}
