package com.dam.parking;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class VehiculosActivity extends AppCompatActivity {

    private ListView listViewVehiculos;
    private ArrayAdapter<String> vehiculoAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehiculos);

        listViewVehiculos = findViewById(R.id.list_view_vehiculos);

        // Obtener la lista de vehículos del usuario
        App myApp = (App) getApplication();
        String dni = myApp.getDni();

        //String apiUrl = Constants.API_URL + "/api/vehiculos/usuario?dni=" + dni;
        new GetVehiculosTask().execute(dni);

        // Botón Volver
        Button btnVolver = findViewById(R.id.button_volver_vehiculos);
        btnVolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(VehiculosActivity.this, HomeActivity.class));
            }
        });

        // Botón Agregar Vehículo
        Button btnAgregarVehiculo = findViewById(R.id.button_agregar_vehiculo);
        btnAgregarVehiculo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(VehiculosActivity.this, NuevoVehiculoActivity.class));
            }
        });
    }

    private class GetVehiculosTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String dni = params[0];
            try {

                String apiUrl = Constants.API_URL + "/api/vehiculos?dni=" + dni;
                URL url = new URL(apiUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();

                // Configurar la conexión
                connection.setRequestMethod("GET");
                connection.setReadTimeout(10000);
                connection.setConnectTimeout(15000);

                // Obtener la respuesta
                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();
                    return response.toString();
                } else {
                    return "Error en la petición";
                }
            } catch (IOException e) {
                e.printStackTrace();
                return "Error en la petición";
            }
        }

        @Override
        protected void onPostExecute(String response) {
            if (!response.equals("Error en la petición")) {
                mostrarListaVehiculos(response);
            }
        }
    }

    private void mostrarListaVehiculos(String json) {
        try {
            JSONArray vehiculosArray = new JSONArray(json);
            List<String> vehiculos = new ArrayList<>();

            // Crear una lista para almacenar las matrículas
            List<String> matriculas = new ArrayList<>();

            for (int i = 0; i < vehiculosArray.length(); i++) {
                JSONObject vehiculoObject = vehiculosArray.getJSONObject(i);
                String matricula = vehiculoObject.getString("matricula");
                String marca = vehiculoObject.getString("marca");
                String modelo = vehiculoObject.getString("modelo");
                int plazas = vehiculoObject.getInt("plazas");

                String vehiculoInfo = "Matrícula: " + matricula + "\nMarca: " + marca + "\nModelo: " + modelo + "\nPlazas: " + plazas;
                vehiculos.add(vehiculoInfo);

                // Agregar cada matrícula a la lista
                matriculas.add(matricula);
            }

            // Guardar la lista de matrículas en la instancia de la aplicación
            App myApp = (App) getApplication();
            myApp.setMatriculas(matriculas);

            vehiculoAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, vehiculos);
            listViewVehiculos.setAdapter(vehiculoAdapter);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}




