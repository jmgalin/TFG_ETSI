package com.dam.parking;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.TextHttpResponseHandler;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import cz.msebera.android.httpclient.Header;

public class CheckoutActivity extends AppCompatActivity {

    TextView orderID_label;
    Button confirm_btn;
    String orderID;

    String API_URL;

    private double precioDouble;
    private String precio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        // Obtener el precio de la estancia en el parking
        App myApp = (App) getApplication();
        precioDouble = myApp.getPrecio();
        precio = String.valueOf(precioDouble);

        TextView textViewPrecio = findViewById(R.id.amt);
        textViewPrecio.setText("Total a pagar: " + precio + " €");

        //captura el orderID del parámetro de la petición
        Uri redirectUri = getIntent().getData();
        orderID = redirectUri.getQueryParameter("token");

        //muestra el orderID
        orderID_label = (TextView) findViewById(R.id.orderID);
        orderID_label.setText("ID compra: " +orderID);

        //añade un onClick listener al botón de confirmación
        confirm_btn = findViewById(R.id.confirm_btn);
        confirm_btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                captureOrder(orderID); //función para finalizar el pago
            }
        });
    }

    void captureOrder(String orderID){
        //captura el accessToken del PaymentActivity
        String accessToken = PagoActivity.getMyAccessToken();

        AsyncHttpClient client = new AsyncHttpClient();
        client.addHeader("Accept", "application/json");
        client.addHeader("Content-type", "application/json");
        client.addHeader("Authorization", "Bearer " + accessToken);

        client.post("https://api-m.sandbox.paypal.com/v2/checkout/orders/"+orderID+"/capture", new TextHttpResponseHandler() {
            @Override
            public void onFailure(int statusCode, Header[] headers, String response, Throwable throwable) {
                Log.e("RESPONSE", response);
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, String response) {
                try {
                    JSONObject jobj = new JSONObject(response);

                    // Obtener la matricula que realiza el pago
                    App myApp1 = (App) getApplication();
                    String matricula = myApp1.getMatriculaseleccionada();


                    realizarPagoPOST(matricula, orderID);

                    Toast.makeText(getApplicationContext(), "Pago realizado correctamente", Toast.LENGTH_SHORT).show();
                    //redirect back to home page of app
                    Intent intent = new Intent(CheckoutActivity.this, HomeActivity.class);
                    startActivity(intent);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void realizarPagoPOST(String matricula, String orderID) {
        new CheckoutActivity.PagoPOSTTask().execute(matricula, orderID);
    }
    private class PagoPOSTTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            String matricula = params[0];
            String id_pago = params[1];

            try {

                App myApp = (App) getApplication();
                API_URL = myApp.getDireccionurl();

                // Construir la URL de la petición POST
                String url = API_URL + "/api/parking/pago";
                URL urlObject = new URL(url);

                // Crear un objeto HttpURLConnection
                HttpURLConnection connection = (HttpURLConnection) urlObject.openConnection();
                connection.setRequestMethod("POST");
                connection.setReadTimeout(10000);
                connection.setConnectTimeout(15000);
                connection.setDoOutput(true);

                // Crear un mapa con los parámetros de la solicitud
                Map<String, String> parameters = new HashMap<>();
                parameters.put("matricula", matricula);
                parameters.put("id_pago", id_pago);

                // Escribir los parámetros en el cuerpo de la solicitud
                OutputStream os = connection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                writer.write(getPostDataString(parameters));
                writer.flush();
                writer.close();
                os.close();

                // Obtener la respuesta
                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String responseText = reader.readLine();
                    reader.close();
                    return responseText.toString();
                }

                connection.disconnect();
            } catch (IOException e) {
                e.printStackTrace();
                return "Error en la petición";
            }
            return "OK";
        }

        private String getPostDataString(Map<String, String> params) throws UnsupportedEncodingException {
            StringBuilder result = new StringBuilder();
            boolean first = true;

            for (Map.Entry<String, String> entry : params.entrySet()) {
                if (first) {
                    first = false;
                } else {
                    result.append("&");
                }

                result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
                result.append("=");
                result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
            }

            return result.toString();
        }

        /*@Override
        protected void onPostExecute(String resultado) {

        }*/
    }

}
