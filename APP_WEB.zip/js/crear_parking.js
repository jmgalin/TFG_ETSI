// Función para validar el formulario antes de enviarlo
function validarFormulario() {
    const tipo = document.getElementById('tipo').value;
    const nombre = document.getElementById('nombre').value;
    const categoria = document.getElementById('categoria').value;
    const tipoCarga = document.getElementById('tipoCarga').value;
    const moneda = document.getElementById('moneda').value;
    const tarifa = document.getElementById('tarifa').value;
    const latitud = document.getElementById('latitud').value;
    const longitud = document.getElementById('longitud').value;
    const tipoVehiculoPermitido = document.getElementById('tipoVehiculoPermitido').value;
    const direccion = document.getElementById('direccion').value;
    const ciudad = document.getElementById('ciudad').value;
    const pais = document.getElementById('pais').value;
    const codigoPostal = document.getElementById('codigoPostal').value;
    const totalPlazas = document.getElementById('totalPlazas').value;
    const alturaMaxima = document.getElementById('alturaMaxima').value;
    const anchuraMaxima = document.getElementById('anchuraMaxima').value;
    const tipoParking = document.getElementById('tipoParking').value;

    // Verifica si algún campo está vacío
    if (tipo === '' || nombre === '' || categoria === '' || tipoCarga === '' || moneda === '' || tarifa === '' || latitud === '' || longitud === '' || tipoVehiculoPermitido === '' || direccion === '' || ciudad === '' || pais === '' || codigoPostal === '' || totalPlazas === '' || alturaMaxima === '' || anchuraMaxima === '' || tipoParking === '') {
        alert('Por favor, rellena todos los campos del formulario.');
        return false; // Detiene el envío del formulario
    }
    return true; // El formulario está validado correctamente
}


// Función para registrar un nuevo parking
function registrarNuevoParking() {

    // Validar el formulario antes de enviarlo
    if (!validarFormulario()) {
        return; // Detiene la ejecución de la función si el formulario no está validado
    }

    // Obtener los valores de los campos del formulario
    const formData = new FormData();
    formData.append('type', document.getElementById('tipo').value);
    formData.append('name', document.getElementById('nombre').value);
    formData.append('category', document.getElementById('categoria').value);
    formData.append('chargetype', document.getElementById('tipoCarga').value);
    formData.append('pricecurrency', document.getElementById('moneda').value);
    formData.append('pricerateperminute', parseFloat(document.getElementById('tarifa').value));
    formData.append('latitude', parseFloat(document.getElementById('latitud').value));
    formData.append('longitude', parseFloat(document.getElementById('longitud').value));
    formData.append('allowedvehicletype', document.getElementById('tipoVehiculoPermitido').value);
    formData.append('address', document.getElementById('direccion').value);
    formData.append('city', document.getElementById('ciudad').value);
    formData.append('country', document.getElementById('pais').value);
    formData.append('postcode', document.getElementById('codigoPostal').value);
    formData.append('totalslotnumber', parseInt(document.getElementById('totalPlazas').value));
    formData.append('availableslotnumber', parseInt(0));
    formData.append('occupiedslotnumber', parseInt(0));
    formData.append('occupancy', parseFloat(0));
    formData.append('maximumallowedheight', document.getElementById('alturaMaxima').value);
    formData.append('maximumallowedwidth', document.getElementById('anchuraMaxima').value);
    formData.append('type_parking', document.getElementById('tipoParking').value);

    // Realizar solicitud POST para crear un nuevo parking
    fetch('http://192.168.118.129:8080/api/parking', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (response.ok) {
            response.text().then(body => {
                alert(body);
            });
            //alert('Nuevo parking creado exitosamente.');
            // Puedes hacer algo adicional aquí, como redirigir a otra página o actualizar la lista de parkings
        } else {
            
            response.text().then(body => {
                alert('Error: ' + body); // Muestra el mensaje de error devuelto por el servidor
            });
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error al crear el nuevo parking.');
    });
}

