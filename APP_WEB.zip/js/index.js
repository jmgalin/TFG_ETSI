function verEstadoParking() {
    window.location.href = "estado_parking.html";
}

function verReservas() {
    window.location.href = "reservas.html";
}

function crearNuevoParking() {
    window.location.href = "crear_parking.html";
}
