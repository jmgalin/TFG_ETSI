// Obtener el formulario
const parkingForm = document.getElementById('parkingForm');

// Realizar una solicitud GET para obtener el estado actual del parking
fetch('http://192.168.118.129:8081/api/parking')
    .then(response => response.json())
    .then(data => {
        // Mostrar los datos en el formulario
        const parking = data[0];
        document.getElementById('nombre').value = parking.name;
        document.getElementById('totalPlazas').value = parking.totalSlotNumber;
        document.getElementById('plazasOcupadas').value = parking.occupiedSlotNumber;
        document.getElementById('tarifa').value = parking.priceRatePerMinute;
        document.getElementById('tipoCarga').value = parking.chargeType;
    })
    .catch(error => {
        console.error('Error al obtener el estado del parking:', error);
        alert('Error al obtener el estado del parking');
    });

// Agregar un controlador de eventos para el envío del formulario
parkingForm.addEventListener('submit', function(event) {
    event.preventDefault();

    const totalSlots = document.getElementById('totalPlazas').value;
    const occupiedSlots = document.getElementById('plazasOcupadas').value;
    const priceRatePerMinute = document.getElementById('tarifa').value;
    const chargeType = document.getElementById('tipoCarga').value;

    const formData = new FormData();
    formData.append('totalSlotNumber', parseInt(totalSlots));
    formData.append('occupiedSlotNumber', occupiedSlots);
    formData.append('priceRatePerMinute', priceRatePerMinute);
    formData.append('chargeType', chargeType);

    fetch('http://192.168.118.129:8081/api/parking', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (response.ok) {
            alert('Los cambios han sido guardados correctamente.');
        } else {
            throw new Error('Error al guardar los cambios.');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error al guardar los cambios.');
    });
});
