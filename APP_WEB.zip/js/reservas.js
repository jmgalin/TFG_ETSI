// Hacer la petición GET para obtener las reservas
fetch('http://192.168.118.129:8080/api/reserva/1')
.then(response => response.json())
.then(reservas => {
    // Ordenar las reservas por fecha de inicio
    reservas.sort((a, b) => new Date(a.fecha_inicio) - new Date(b.fecha_inicio));

    const reservasTable = document.getElementById('reservasTable');

    reservas.forEach(reserva => {
        const row = reservasTable.insertRow();

        // Formatear las fechas
        const fechaInicio = new Date(reserva.fecha_inicio).toLocaleString('es-ES');
        const fechaFin = new Date(reserva.fecha_fin).toLocaleString('es-ES');

        row.innerHTML = `
            <td>${reserva.reserva_id}</td>
            <td>${reserva.matricula}</td>
            <td>${fechaInicio}</td>
            <td>${fechaFin}</td>
            <td>${reserva.confirmada ? 'Confirmada' : 'No Confirmada'}</td>
            <td>
                ${reserva.confirmada 
                    ? `<button onclick="noConfirmarReserva('${reserva.reserva_id}')" class="sin-confirmar">No Confirmar</button>`
                    : `<button onclick="confirmarReserva('${reserva.reserva_id}')">Confirmar</button>`
                }
            </td>
        `;
    });
})
.catch(error => console.error('Error al obtener las reservas:', error));


// Función para confirmar una reserva
function confirmarReserva(idReserva) {
    fetch(`http://192.168.118.129:8080/api/reserva/confirmacion/${idReserva}`, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json' // Cambiar el tipo de contenido a JSON
        },
        body: JSON.stringify({ confirmada: true }) // Enviar el estado de confirmada como true
    })
    .then(response => {
        if (response.ok) {
            alert('Reserva confirmada exitosamente');
            location.reload(); // Recargar la página para actualizar la tabla
        } else {
            throw new Error('Error al confirmar reserva');
        }
    })
    .catch(error => console.error('Error al confirmar reserva:', error));
}

// Función para cancelar confirmación de una reserva
function noConfirmarReserva(idReserva) {
    fetch(`http://192.168.118.129:8080/api/reserva/confirmacion/${idReserva}`, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json' // Cambiar el tipo de contenido a JSON
        },
        body: JSON.stringify({ confirmada: false }) // Enviar el estado de confirmada como false
    })
    .then(response => {
        if (response.ok) {
            alert('Reserva en estado no confirmada');
            location.reload(); // Recargar la página para actualizar la tabla
        } else {
            throw new Error('Error al no confirmar reserva');
        }
    })
    .catch(error => console.error('Error al no confirmar reserva:', error));
}
